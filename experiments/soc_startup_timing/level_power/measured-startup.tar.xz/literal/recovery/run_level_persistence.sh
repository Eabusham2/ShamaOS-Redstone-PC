#!/bin/bash
set -eu
. /home/user/shama-test-tools/env.sh
export OPENBLAS_NUM_THREADS=1 LEVEL_POWER_SOURCE=/home/user/level-power-recovery SHAMA_NATIVE_PROGRESS=1
tools=/home/user/level-power-evidence
skew=/home/user/level-c7-replay
while kill -0 2285 2>/dev/null; do
 if grep -q '^measured_status=' /home/user/level-replay-serial.log; then break; fi
 state=$(ps -o stat= -p 2285)
 if [[ "$state" = *Z* ]]; then break; fi
 sleep 3
done
grep -q '^measured_status=0$' /home/user/level-replay-serial.log || { echo 'prior native measurement did not pass'; exit 1; }
PERSIST_STOP=snapshot python3 -u "$tools/persist_measured.py" "$skew"
PERSIST_STOP=restore python3 -u "$tools/persist_measured.py" "$skew"
python3 -u "$tools/persist_measured.py" "$skew"
python3 - "$skew" <<'PY'
from pathlib import Path
import json, sys
root=Path(sys.argv[1])/'persistence'
q=json.loads((root/'summary.json').read_bytes())
assert q['snapshot_pending_ticks']==0 and q['all_states_correct'] and q['all_local_setup_hold']
assert q['modified_words_reopened_from_anvil']==[0,0x12345678,0x11223344,0xABCDEF01]
assert q['shutdown_ready_pad_persisted_high'] and q['core_widths']==[35] and q['all_core_highs_under_reset']
assert q['row_write']==q['pending_write']==[]
print('strict persisted lifecycle gate passed')
PY
