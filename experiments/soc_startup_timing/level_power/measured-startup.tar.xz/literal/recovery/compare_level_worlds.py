"""Compare every physical section and assert there are exactly three expected delay changes."""
import hashlib
import json
from itertools import zip_longest
from pathlib import Path
import sys

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def check_native_header(obj, base):
    assert obj['kind'] == 'header' and obj['schema']=='shama-native-anvil-sections-v2'
    source=obj['source']
    assert source['data_version']==3700 and digest(base/'world/level.dat')==source['level_dat_sha256']
    for info in source['regions']:
        f=base/'world/region'/info['name']
        assert f.stat().st_size==info['bytes'] and digest(f)==info['sha256']

def literals(sec):
    width=sec['bits']
    per=64//width
    for i in range(4096):
        yield sec['palette'][(sec['data'][i//per] >> (width*(i%per))) & ((1<<width)-1)]

base, skew=map(Path, sys.argv[1:])
expect={tuple(c['pos']):c for c in json.loads((skew/'private-power-C.json').read_bytes())['power_C']}
seen=set(); changed_records=[]; last_kind=None
with (base/'world.jsonl').open('rb') as left,(skew/'world.jsonl').open('rb') as right:
 for line,(a,b) in enumerate(zip_longest(left,right),1):
    assert a and b
    if a==b:continue
    x,y=json.loads(a),json.loads(b)
    assert x['kind']==y['kind']
    if x['kind']=='header':
        check_native_header(x,base);check_native_header(y,skew)
        assert x['surface_y']==y['surface_y']
        assert [(f['name'],f['bytes']) for f in x['source']['regions']]==[(f['name'],f['bytes']) for f in y['source']['regions']]
        continue
    assert x['kind']=='section',(line,x['kind'])
    assert x['chunk']==y['chunk'] and x['y']==y['y'] and x['nonair']==y['nonair']
    changed_records.append(line)
    for index,(first,second) in enumerate(zip(literals(x),literals(y))):
        if first==second:continue
        pos=(x['chunk'][0]*16 + index%16, x['y']*16 + index//256, x['chunk'][1]*16 + (index//16)%16)
        wanted=expect[pos]
        assert pos not in seen and first['name']==second['name']=='minecraft:repeater'
        assert first['properties']==wanted['old'] and second['properties']==wanted['new']
        assert {k for k in wanted['old'] if wanted['old'][k]!=wanted['new'][k]}=={'delay'}
        seen.add(pos)
assert len(seen)==len(expect)==3 and seen==expect.keys()
assert sum(int(v['new']['delay'])-int(v['old']['delay']) for v in expect.values())==7
report={'records_compared':line,'changed_section_lines':changed_records,'changed_positions':sorted(seen),
        'baseline_stream_sha256':digest(base/'world.jsonl'),'retimed_stream_sha256':digest(skew/'world.jsonl')}
(skew/'geometry-graded.json').write_text(json.dumps(report,indent=2)+'\n')
print(report)
