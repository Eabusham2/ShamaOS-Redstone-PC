"""Persist a real changed row after clean power-off, then reboot twice with a stale acknowledgment."""
from pathlib import Path
import json,sys,os,subprocess,gzip,hashlib
from bisect import bisect_left,bisect_right
from itertools import groupby
root=Path(os.environ.get('LEVEL_POWER_SOURCE','/home/user/level-power-recovery'));sys.path[:0]=[str(root/'src'),str(root/'tools'),str(root/'tests')]
import prove_soc_cold_clock as proof
from shamaos.mchprs_snapshot import restore_snapshot
from shamaos.worldio import NativeWorldReader
from shamaos.mchprs_import import export_world
base=Path(sys.argv[1]);dest=base/'persistence';dest.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_bytes())
write=lambda p,o:p.write_text(json.dumps(o,indent=2)+'\n')
sha=lambda f:hashlib.file_digest(f.open('rb'),'sha256').hexdigest()
def runs(t):
 a=0;r=[]
 for high,g in groupby(t):
  n=sum(1 for _ in g)
  if high:r.append([a+1,a+n])
  a+=n
 return r
def native(name,case,stream,snapshot=False):
 f=dest/(name+'.json');write(f,case)
 cmd=[os.environ['SHAMA_MCHPRS_TERRAIN_RUNNER'],str(stream),str(f),str(read(base/'readback.json')['chunks']+128)]
 if snapshot:cmd.extend(['--snapshot',str(dest/'off-snapshot.jsonl')])
 with (dest/(name+'-result.json')).open('w') as out,(dest/(name+'-progress.jsonl')).open('w')as err:subprocess.run(cmd,check=True,stdout=out,stderr=err,timeout=360)
 r=read(dest/(name+'-result.json'));assert r['imported_stream_sha256']==sha(stream) and r['scenario_sha256']==sha(f)
 return r
def cycles(steps,count,change=None):
 for i in range(count):
  steps.append({'drive':{'clk':True,**(change if change and i==0 else {})},'ticks':35})
  steps.append({'drive':{'clk':False},'ticks':35})
def total(steps):return sum(s['ticks'] for s in steps)
probes=read(base/'probes.json');orig_write=read(base/'write.json')
memory={f'stored_{i}_{b}':bool(w & (1<<b)) for i,w in enumerate((0,*proof.WORDS[1:])) for b in range(32)}
stable=memory|{'write_commit':False,'row_write':False}
def state_at_end(steps,hold,reset):steps[-1]['expect']=steps[-1].get('expect',{})|{'clock_hold_Q':hold,'reset_Y':reset}
if not (dest/'off-result.json').exists() or not (dest/'off-snapshot.jsonl').is_file():
 case=orig_write.copy();steps=list(orig_write['steps']);extra=[]
 cycles(extra,40,{'power_switch':False,'shutdown_ready':False});cycles(extra,40,{'shutdown_ready':True})
 for s in extra:s.update(expect=stable,continuous=True)
 extra.append({'ticks':2048,'expect':stable|{'clock_hold_Q':False,'reset_Y':True},'continuous':True})
 steps.extend(extra);case.update(steps=steps,trace_outputs=['row_write','clock_hold_Q','reset_Y','core_clk_Y'])
 print('saving changed row and clean powered-off world',flush=True);saved=native('off',case,base/'world.jsonl',True)
else:saved=read(dest/'off-result.json')
if os.environ.get('PERSIST_STOP')=='snapshot':
 print('snapshot pending events',saved['pending_ticks_after_scenario'],saved['snapshot']['status'],flush=True)
 sys.exit(0)
assert saved['pending_ticks_after_scenario']==0 and saved['snapshot']['status']=='quiescent-snapshot-written'
snap=dest/'off-snapshot.jsonl';assert sha(snap)==saved['snapshot']['sha256']
world=dest/'reopened-world'
if not world.exists():
 print('restoring snapshot as Anvil',flush=True);restored=restore_snapshot(snap,base/'world',world,expected_sha256=sha(snap));write(dest/'restoration.json',restored)
restored=read(dest/'restoration.json')
assert restored==read(world/'shamaos/quiescent-snapshot.json')
assert restored['status']=='quiescent-snapshot-native-readback-passed'
assert restored['snapshot_sha256']==sha(snap) and restored['parent_imported_stream_sha256']==sha(base/'world.jsonl')
assert restored['parent_scenario_sha256']==sha(dest/'off.json') and restored['pending_scheduled_ticks']==0
for key in ('chunks','sections','nonair','comparators'):
 assert restored[key]==saved['snapshot'][key]
assert restored['original_chunk_inventory_preserved'] and restored['original_source_chunks']==read(base/'readback.json')['chunks']
write(dest/'readback.json',restored)
reader=NativeWorldReader(world);words=[0]*4
for i in range(4):
 for b in range(32):
  st=reader.get_block(proof.Vec3(*probes[f'stored_{i}_{b}']))
  assert st.name=='minecraft:repeater';words[i]|=(dict(st.properties)['powered']=='true')<<b
assert words==[0,*proof.WORDS[1:]]
stream=dest/'reopened.jsonl'
if not stream.exists():write(dest/'reopened-import.json',export_world(world,stream))
if os.environ.get('PERSIST_STOP')=='restore':
 print('restored actual words',words,sha(stream),flush=True)
 sys.exit(0)
ports=read(base/'power-cycle.json')['outputs']
first=[];marks=[]
def mark(h,r):marks.append((total(first),h,r))
ready_ref=orig_write['inputs']['shutdown_ready'];ready_pad=proof.Vec3(*ready_ref).offset(dz=1)
assert reader.get_block(ready_pad).name=='minecraft:redstone_block'
power_ref=orig_write['inputs']['power_switch'];assert reader.get_block(proof.Vec3(*power_ref).offset(dz=1)).name=='minecraft:air'
first.append({'ticks':2048});mark(False,True)
for which in range(2):
 first.append({'drive':{'power_switch':True},'ticks':12});cycles(first,32);mark(True,True)
 cycles(first,40,{'shutdown_ready':False});mark(True,False)
 if which==0:
  cycles(first,40,{'power_switch':False});mark(True,False)
  cycles(first,40,{'shutdown_ready':True});mark(False,True)
  first.append({'ticks':2048});mark(False,True)
for s in first:s.update(expect=stable,continuous=True)
trace=['clock_hold_Q','core_clk_Y','reset_Y','row_write','pending_Q']+[k for k in ports if k.startswith('timing_') or (k.startswith('receiver_') and k[-2:] in ('_C','_D','_Q'))]
case={'inputs':orig_write['inputs'],'outputs':ports,'initial_ticks':0,'capture_trace':True,'trace_outputs':trace,'steps':first}
print('fresh engine two short-lead restarts',flush=True);res=native('reopen',case,stream)
w=res['traces'];points=[{'tick':n,'expected':[bool(h),bool(r)],'actual':[w['clock_hold_Q'][n-1],w['reset_Y'][n-1]]} for n,h,r in marks]
def local(source,prefix):
 c,d=(w[prefix+signal] for signal in ('C','D'));edges=[i for i in range(1,len(d)) if d[i]!=d[i-1]];samples=[]
 for i in range(2060,len(c)-2):
  if c[i] and not c[i-1]:
   left,right=bisect_right(edges,i),bisect_left(edges,i);samples.append((i+1,i-(edges[left-1] if left else 0),(edges[right] if right<len(edges) else len(d))-i))
 return {'setup':min(s for _,s,_ in samples),'hold':min(h for _,_,h in samples),'below':[[i,s,h] for i,s,h in samples if s<8 or h<2],'edges':len(samples)}
margins={s:local(s,'timing_'+s+'_') for s in proof.POWER_REGISTERS}
margins.update({s:local(s,'receiver_'+s+'_') for s in ('state_0','state_1','state_2','bank','write_enable','pending')})
high=runs(w['core_clk_Y']);rep={'source_sha256':sha(base/'world.jsonl'),'modified_words_reopened_from_anvil':words,'snapshot_sha256':sha(snap),'snapshot_pending_ticks':saved['pending_ticks_after_scenario'],'reimport_sha256':sha(stream),'reopened_ticks':res['ticks'],'shutdown_ready_pad_persisted_high':True,'on_off_checkpoints':points,'all_states_correct':all(a['expected']==a['actual'] for a in points),'local_margins':margins,'all_local_setup_hold':all(not a['below'] for a in margins.values()),'core_highs':len(high),'core_widths':sorted(set(b-a+1 for a,b in high)),'all_core_highs_under_reset':all(all(w['reset_Y'][a-1:b]) for a,b in high),'row_write':runs(w['row_write']),'pending_write':runs(w['pending_Q']),'whole_machine_runtime_verified':False}
write(dest/'summary.json',rep);print({k:rep[k] for k in ('all_states_correct','all_local_setup_hold','core_highs','core_widths','modified_words_reopened_from_anvil')})
