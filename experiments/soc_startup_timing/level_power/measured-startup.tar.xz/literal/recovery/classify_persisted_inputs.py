"""Record the genuine stored state and the original fresh-run preflight rejection."""
import hashlib,json,sys
from pathlib import Path
source,world=map(Path,sys.argv[1:])
sys.path.insert(0,str(source/'src'))
from shamaos.worldio import NativeWorldReader
from shamaos.model import Vec3
p=world/'persistence'
read=lambda f:json.loads(f.read_bytes())
sha=lambda f:hashlib.file_digest(f.open('rb'),'sha256').hexdigest()
native=NativeWorldReader(p/'reopened-world')
probes=read(world/'probes.json')
case=read(p/'reopen.json')
words=[0]*4
for row in range(4):
    for bit in range(32):
        state=native.get_block(Vec3(*probes[f'stored_{row}_{bit}']))
        assert state.name=='minecraft:repeater'
        words[row]|=(dict(state.properties)['powered']=='true')<<bit
assert words==[0,0x12345678,0x11223344,0xABCDEF01]
pads={}
for key,point in case['inputs'].items():
    pos=Vec3(*point).offset(dz=1)
    name=native.get_block(pos).name
    if name!='minecraft:air':pads[key]={'block':name,'position':[pos.x,pos.y,pos.z]}
assert set(pads)=={'core_gate','shutdown_ready'} and all(v['block']=='minecraft:redstone_block' for v in pads.values())
error=(p/'reopen-progress.jsonl').read_text()
assert 'external drive pad would overwrite a saved block' in error
report={'observed_words':words,'nonair_declared_drive_pads':pads,'observed_power_pad':'minecraft:air',
        'result_produced':False,'executed_reopen_ticks':0,'failure':'scenario preflight rejected a declared drive pad already occupied by a persisted redstone block',
        'reopened_stream_sha256':sha(p/'reopened.jsonl'),'reopen_scenario_sha256':sha(p/'reopen.json'),
        'reopen_stderr_sha256':sha(p/'reopen-progress.jsonl'),'engine_revision':'f9e10d2572116bf5dcb9a36a305f28e40641a61a'}
(p/'preflight-failure.json').write_text(json.dumps(report,indent=2)+'\n')
print(report)
