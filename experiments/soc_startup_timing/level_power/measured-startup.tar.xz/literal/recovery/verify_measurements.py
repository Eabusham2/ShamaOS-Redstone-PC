"""Verify the retained replay inputs, physical waveforms and optional shutdown snapshot."""
from bisect import bisect_left, bisect_right
from itertools import groupby
from hashlib import sha256
import json
import sys
from zipfile import ZipFile

SHELL=("clock_hold","divided_clock_active","reset_pulse_request","reset_pulse_received")
RECEIVERS=("state_0","state_1","state_2","bank","write_enable","pending")
WORDS=(0xA55AC33C,0x12345678,0x11223344,0xABCDEF01)

def runs(trace):
    idx,result=0,[]
    for value,group in groupby(trace):
        count=sum(1 for value in group)
        if value: result.append((idx + 1,idx + count))
        idx+=count
    return result

def margins(wave,prefix,first):
    c,d=wave[prefix+"C"],wave[prefix+"D"]
    change=[i for i in range(1,len(d)) if d[i]!=d[i-1]]
    edges=[]
    for i in range(first,len(c)-2):
        if c[i] and not c[i-1]:
            a,b=bisect_right(change,i),bisect_left(change,i)
            edges.append([i+1,i-(change[a-1] if a else 0),(change[b] if b<len(change) else len(d))-i])
    assert edges
    return {"edges":len(edges),"minimum_setup":min(e[1] for e in edges),"minimum_hold":min(e[2] for e in edges),
            "violations":[e for e in edges if e[1]<8 or e[2]<2]}

def verify(path):
    with ZipFile(path) as z:
        read=lambda n:json.loads(z.read(n))
        manifest=read("manifest.json")
        files=manifest["files"]
        assert len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(files)|{"manifest.json"}
        for key,spec in files.items():
            with z.open(key) as stream:
                h=sha256()
                while block:=stream.read(1048576): h.update(block)
            assert h.hexdigest()==spec["sha256"] and z.getinfo(key).file_size==spec["bytes"],key
        assert manifest["full_pc_runtime_verified"] is manifest["whole_system_timing_verified"] is False
        native=lambda prefix,name:read(prefix+"/"+name+"-result.json")
        for prefix, names in (("level",("power-cycle",)),("retimed",("power-cycle","cold","write","receiver-idle",
                                  "receiver-out-of-range","receiver-write","lead-12","lead-55","lead-95","lead-157"))):
            stream_hash=files[prefix+"/world.jsonl"]["sha256"]
            for case in names:
                trial=native(prefix,case);casepath=prefix+"/"+case+".json";ctx=read(casepath)
                assert trial["status"]=="passed" and trial["scenario_sha256"]==files[casepath]["sha256"]
                assert trial["imported_stream_sha256"]==stream_hash and trial["complete_machine_runtime_verified"] is False
                assert trial["engine_revision"]=="f9e10d2572116bf5dcb9a36a305f28e40641a61a"
                assert trial["ticks"]==sum(step["ticks"] for step in ctx["steps"])
                assert trial['assertions']==sum(len(step.get('expect',{})) for step in ctx['steps'])
                wave=trial["traces"]
                if case=="cold":
                    for row,value in enumerate(WORDS):
                        for bit in range(32):
                            assert all(s==bool(value & 1<<bit) for s in wave[f"stored_{row}_{bit}"])
                    assert not any(wave["row_write"])
                if case=="write":
                    assert runs(wave["row_write"])==[(205428,221811),(328308,344691)]
                    assert ctx['steps'][-1]['expect']=={f'stored_{i}_{b}':bool(w & 1<<b)
                                                         for i,w in enumerate([0,*WORDS[1:]]) for b in range(32)}
                if case.startswith("receiver-"):
                    label=case[len("receiver-"):]
                    r=read("retimed/receiver-idle-graded.json")["receiver_suite"][label]
                    assert not r["errors"] and r["ticks"]==15866
                    for role in RECEIVERS:
                        cell=r["leaves"][role]
                        clk=wave["receiver_"+role+"_C"]
                        edges=runs(clk[:r["before_divider"]])
                        assert len(edges)==17==cell["raw_pulses"]
                        assert all(b-a+1==35 and all(all(wave[p][a-1:b]) for p in cell["reset_qualifiers"]) for a,b in edges)
                        assert not any(wave["receiver_"+role+"_Q"][:r["before_divider"]])
                if case!="power-cycle" and not case.startswith("lead-"): continue
                raw=0
                for step in ctx["steps"]:
                    if step.get("drive",{}).get("clk") is True:break
                    raw+=step["ticks"]
                result=read(prefix+"/"+case+"-graded.json")
                calculated={r:margins(wave,"timing_"+r+"_",raw) for r in SHELL}
                calculated.update({r:margins(wave,"receiver_"+r+"_",raw) for r in RECEIVERS})
                assert calculated==result["margins"]
                low={k:v["violations"] for k,v in calculated.items() if v["violations"]}
                assert low==({"clock_hold":[[15333,1,4473]]} if prefix=="level" else {})
                gates=[(k, runs(v)) for k,v in wave.items() if k.startswith("gate_")]
                assert dict(gates)=={k:list(map(tuple,v)) for k,v in result["gate_output_highs"].items()}
                active=runs(wave["gate_shell_raw_clock_path_Y"])
                assert active and all(b-a+1==35 for a,b in active)
                if case=="power-cycle":
                    assert len(active)==136 and not any(wave["gate_shell_divided_clock_path_Y"])
                    for tick,expected,actual in result["checkpoints"]:
                        assert expected==actual==[wave["receiver_clock_hold"][tick-1],wave["receiver_rst"][tick-1]]
                    for role in RECEIVERS:
                        edges=runs(wave["receiver_"+role+"_C"])
                        pins=result["local_pulses"][role]["reset_inputs"]
                        assert len(edges)==136 and all(b-a+1==35 for a,b in edges)
                        assert all(all(all(wave[p][a-1:b]) for p in pins) for a,b in edges)
                else:
                    start=result["before_divider"]
                    q=[r for r in RECEIVERS if wave["receiver_"+r+"_Q"][-1]]
                    expected=("state_1","state_2") if case=="lead-95" else ("state_0","write_enable")
                    assert set(q)==set(expected)
                    assert not any(any(wave["receiver_"+r+"_Q"][:start]) for r in RECEIVERS)
                    divided=runs(wave["gate_shell_divided_clock_path_Y"])
                    assert len(divided)==1 and divided[0][1]-divided[0][0]+1==1024
        geo=read("retimed/geometry-graded.json")
        assert geo["records_compared"]==109719
        assert geo["changed_positions"]==[[1680,-31,339],[1680,-31,348],[1680,-31,358]]
        for prefix in ('level','retimed'):
            with z.open(prefix+'/world.jsonl') as f: header=json.loads(f.readline())
            for reg in header['source']['regions']:
                assert files[prefix+'/world/region/'+reg['name']]['sha256']==reg['sha256']
            assert files[prefix+'/world/level.dat']['sha256']==header['source']['level_dat_sha256']
        p="retimed/persistence/"
        if p+"off-result.json" in files:
            off=read(p+"off-result.json")
            assert off['imported_stream_sha256']==files['retimed/world.jsonl']['sha256']
            assert off['scenario_sha256']==files[p+'off.json']['sha256']
            assert off['pending_ticks_after_scenario']==0 and off['snapshot']['sha256']==files[p+'off-snapshot.jsonl']['sha256']
        if p+"summary.json" in files:
            summary=read(p+"summary.json"); result=read(p+"reopen-result.json")
            assert result['scenario_sha256']==files[p+'reopen.json']['sha256']
            assert result['imported_stream_sha256']==files[p+'reopened.jsonl']['sha256']
            assert summary['modified_words_reopened_from_anvil']==[0,*WORDS[1:]]
            assert summary['all_states_correct'] and summary['all_local_setup_hold'] and summary['all_core_highs_under_reset']
            assert summary['core_widths']==[35] and not summary['pending_write'] and not summary['row_write']
            for role in SHELL+RECEIVERS:
                stem=('timing_' if role in SHELL else 'receiver_')+role+'_'
                m=margins(result['traces'],stem,2060)
                observed=summary['local_margins'][role]
                assert (m['minimum_setup'],m['minimum_hold'],m['edges'],m['violations'])==(observed['setup'],observed['hold'],observed['edges'],observed['below'])
        print(f"Verified {len(files)} files, 11 bound original-world replays and all retained shutdown/reopen measurements.")

if __name__=="__main__":
    verify(sys.argv[1])
