"""Grade native input/stream bindings, ten receiving DFF apertures and physical state."""
import hashlib
import json
from pathlib import Path
import sys
from bisect import bisect_left, bisect_right
from itertools import groupby


def read(path):
    return json.loads(path.read_bytes())

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

def intervals(sequence):
    start, output = 0, []
    for value, group in groupby(sequence):
        count = sum(1 for _ in group)
        if value:
            output.append((start + 1, start + count))
        start += count
    return output

def apertures(clock, data, begin):
    changes = [i for i in range(1, len(data)) if data[i-1] != data[i]]
    observations = []
    for i in range(max(1, begin), len(clock)-2):
        if not (clock[i] and not clock[i-1]):
            continue
        before, after = bisect_right(changes, i), bisect_left(changes, i)
        setup = i - (changes[before-1] if before else 0)
        hold = (changes[after] if after < len(changes) else len(data)) - i
        observations.append([i+1, setup, hold])
    assert observations, "missing observable rising edges"
    return {"edges": len(observations), "minimum_setup": min(s for _,s,h in observations),
            "minimum_hold": min(h for _,s,h in observations),
            "violations": [v for v in observations if v[1] < 8 or v[2] < 2]}

def local_receivers(base):
    import os
    src=Path(os.environ['LEVEL_POWER_SOURCE'])
    sys.path[:0]=[str(src/x) for x in ('src','tools','tests')]
    import prove_soc_cold_clock as p
    from shamaos.hardware.local_router import compact_tile
    from shamaos.hardware.partition_planner import load_mapped_module
    from shamaos.synthesis import build_physical_netlist
    at=compact_tile(build_physical_netlist(base/'joined.json',top='causal',origin=p.Vec3(32,-46,400)),
                    max_cells=177)
    cells=read(base/'joined.json')['modules']['causal']['cells']
    shell,_=load_mapped_module(base/'shell.json','shama_soc')
    sig={n:shell['netnames'][n]['bits'][0] for n in ('clock_hold','core_clk','rst','divided_clock_active')}
    receivers=p.receiver_pins(at,cells,base/'cache.json',sig)
    return p,receivers

def check(base, case_name):
    casefile, outfile = base / (case_name + ".json"), base / (case_name + "-result.json")
    case, actual = read(casefile), read(outfile)
    assert actual['status'] == 'passed'
    assert actual['scenario_sha256'] == sha(casefile)
    assert actual['imported_stream_sha256'] == sha(base / 'world.jsonl')
    assert actual['complete_machine_runtime_verified'] is False
    wave = actual['traces']
    ticks = sum(s['ticks'] for s in case['steps'])
    assert ticks == actual['ticks'] and all(len(w) == ticks for w in wave.values())
    assert set(wave) == set(case.get('trace_outputs',case['outputs']))
    assert actual['assertions'] == sum(len(s.get('expect',{})) for s in case['steps'])
    report = {'ticks': ticks, 'assertions':actual['assertions'],'case_sha256':sha(casefile),
              'stream_sha256':actual['imported_stream_sha256'], 'violations':[]}
    require=lambda v,s: None if v else report['violations'].append(s)
    roles=('state_0','state_1','state_2','bank','write_enable','pending')
    words=(0xA55AC33C,0x12345678,0x11223344,0xABCDEF01)
    if case_name == 'cold':
        for i,value in enumerate(words):
            for b in range(32):
                require(all(x==bool(value&(1<<b)) for x in wave[f'stored_{i}_{b}']),f'cold {i} bit {b} changed')
        for n in ('core_clk_Y','pending_C','pending_Q','guard_Y','write_commit','row_write'):
            require(not any(wave[n]),f'cold {n} active')
    elif case_name == 'write':
        report['row_write']=intervals(wave['row_write'])
        request=0
        for step in case['steps']:
            if step.get('drive',{}).get('req_valid_0') is True: break
            request+=step['ticks']
        require(bool(report['row_write']) and all(a>request for a,b in report['row_write']),'no request-correlated physical row-write')
        report['commit_intervals']=intervals(wave['write_commit'])
        require(bool(report['commit_intervals']) and all(a>request for a,b in report['commit_intervals']),'no request-correlated commit')
        report['changed_word_expected']=0
        require(case['steps'][-1]['expect']=={f'stored_{i}_{b}':bool(v & 1<<b) for i,v in enumerate([0,*words[1:]]) for b in range(32)},'saved write case lacks complete terminal word assertions')
    elif case_name.startswith('receiver-'):
        p,receivers=local_receivers(base)
        def collected(name, testcase):
            instance=read(base/(name+'-result.json'))
            assert instance['scenario_sha256']==sha(base/(name+'.json')) and instance['imported_stream_sha256']==report['stream_sha256']
            # Requested outputs and trace sets come from the actual receiver labels.
            assert set(instance['traces'])==set(testcase['trace_outputs'])
            return instance
        storage={f'stored_{i}_{b}':bool(value&(1<<b)) for i,value in enumerate(words) for b in range(32)}
        details=p.audit_reset_receivers(collected,case['inputs'],read(base/'probes.json'),receivers,storage)
        report['receiver_suite']=details
    else:
        start=0
        for step in case['steps']:
            if step.get('drive',{}).get('clk') is True:
                break
            start+=step['ticks']
        margins={r:apertures(wave['timing_'+r+'_C'], wave['timing_'+r+'_D'], start) for r in
                 ('clock_hold','divided_clock_active','reset_pulse_request','reset_pulse_received')}
        margins.update({r:apertures(wave['receiver_'+r+'_C'], wave['receiver_'+r+'_D'], start) for r in roles})
        report['margins']=margins
        for role,values in margins.items():
            require(not values['violations'],role+' setup/hold')
        report['gate_output_highs']={name:intervals(wave[name]) for name in wave if name.startswith('gate_')}
        core,hold,mode,reset=(wave['receiver_'+name] for name in ('core_clk','clock_hold','divided_clock_active','rst'))
        high=intervals(core)
        if case_name=='power-cycle':
            for name,length in [('core_clk_Y',136),('receiver_clock_hold',2)]:
                require(len(intervals(wave[name]))==length,name+' count')
            require(all(b-a+1==35 and all(reset[a-1:b]) for a,b in high),'core high width/reset failed')
            require(not any(wave['pending_Q']),'unrequested write pending')
            _, topology = local_receivers(base)
            sink_pulses={}
            for role in roles:
                got=intervals(wave['receiver_'+role+'_C'])
                require(len(got)==len(high),role+' clock count differs at local leaf')
                require(all(b-a+1==35 for a,b in got),role+' delivered incomplete pulse')
                for a,b in got:
                    for pin in topology.reset_inputs[role]:
                        require(all(wave[pin][a-1:b]),role+' clock outside local reset '+pin)
                require(not any(wave['receiver_'+role+'_Q']),role+' advanced without divided edge')
                sink_pulses[role]={'pulses':len(got),'widths':sorted({b-a+1 for a,b in got}),
                                   'reset_inputs':topology.reset_inputs[role]}
            report['local_pulses']=sink_pulses
            marks=[]
            total=0
            endpoints={101:(True,False),165:(True,True),229:(True,False),309:(True,False),
                       389:(False,True),455:(True,True),535:(True,False)}
            for i,step in enumerate(case['steps']):
                total+=step['ticks']
                if i in endpoints:
                    expected=endpoints[i]
                    observed=(hold[total-1],reset[total-1])
                    marks.append([total,list(expected),list(observed)])
                    require(observed==expected,'lifecycle checkpoint '+str(i))
            assert len(marks)==7
            report['checkpoints']=marks
        else:
            divider=0
            for step in case['steps']:
                if step.get('drive',{}).get('divider_high') is True:break
                divider+=step['ticks']
            raw=intervals(core[:divider])
            require(bool(raw) and all(b-a+1==35 and all(reset[a-1:b]) for a,b in raw),'invalid raw clock/reset window')
            require(len(intervals(mode))==1 and mode[-1] and len(intervals(hold))==1 and hold[-1],'unstable/missing power or mode')
            require(not reset[divider-1], 'no reset release')
            expected={'state_1','state_2'} if case_name=='lead-95' else {'state_0','write_enable'}
            early=[role for role in roles if any(wave['receiver_'+role+'_Q'][:divider])]
            after=[r for r in roles if wave['receiver_'+r+'_Q'][-1]]
            require(not early and set(after)==expected,'incorrect first divided-edge capture')
            allreset=[name for name in wave if name.startswith('receiver_reset_pin_')]
            assert len(allreset)==7
            _, topology = local_receivers(base)
            leaf_highs={}
            for role in roles:
                raw_leaf=intervals(wave['receiver_'+role+'_C'][:divider])
                divided=intervals(wave['receiver_'+role+'_C'][divider:])
                require(bool(raw_leaf) and all(b-a+1==35 for a,b in raw_leaf),'short raw pulse '+role)
                require(len(divided)==1 and divided[0][1]-divided[0][0]+1==1024,'bad divided '+role)
                for start_tick,end_tick in raw_leaf:
                    for pin in topology.reset_inputs[role]:
                        require(all(wave[pin][start_tick-1:end_tick]),role+' raw pulse outside local reset '+pin)
                    data=wave['receiver_'+role+'_D']
                    require(not any(data[start_tick-1-8:start_tick+2]),role+' reset data unstable')
                q_after=intervals(wave['receiver_'+role+'_Q'][divider:])
                if role in expected:
                    require(len(q_after)==1 and bool(divided) and divided[0][0]<=q_after[0][0]<=divided[0][1],role+' wrong first accepted divided rise')
                else:
                    require(not q_after,role+' extra Q after first deliberate divided clock')
                leaf_highs[role]={'raw':raw_leaf,'divided_relative':divided,'q_relative':q_after,
                                  'local_reset_qualifiers':topology.reset_inputs[role]}
            report.update(before_divider=divider,early_q=early,after_divider=after,leaf_highs=leaf_highs)
        report['core_highs']=high
    report['passed']=not report['violations']
    (base/(case_name+'-graded.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(case_name, report['ticks'], report.get('violations'),{n:(d['minimum_setup'],d['minimum_hold']) for n,d in report.get('margins',{}).items()})
    return report['passed']

if __name__=='__main__':
    raise SystemExit(0 if check(Path(sys.argv[1]),sys.argv[2]) else 1)
