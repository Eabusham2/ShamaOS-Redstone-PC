#!/bin/bash
set -eu
. /home/user/shama-test-tools/env.sh
export OPENBLAS_NUM_THREADS=1 LEVEL_POWER_SOURCE=/home/user/level-power-recovery SHAMA_NATIVE_PROGRESS=1
tools=/home/user/level-power-evidence
base=/home/user/level-replay
skew=/home/user/level-c7-replay
run_native() {
 local dir="$1" name="$2"
 echo "run $dir $name"
 (ulimit -v 393216; "$SHAMA_MCHPRS_TERRAIN_RUNNER" "$dir/world.jsonl" "$dir/$name.json" 4694 > "$dir/$name-result.tmp" 2> "$dir/$name-progress.jsonl")
 mv "$dir/$name-result.tmp" "$dir/$name-result.json"
}
run_native "$base" power-cycle
if python3 "$tools/evaluate_level.py" "$base" power-cycle; then
 echo 'level-only negative control unexpectedly passed'
 exit 1
fi
python3 - "$base" <<'PY'
from pathlib import Path
import json,sys
r=json.loads((Path(sys.argv[1])/'power-cycle-graded.json').read_bytes())
assert r['violations']==['clock_hold setup/hold'] and r['margins']['clock_hold']['violations']==[[15333,1,4473]],r['violations']
PY
python3 -u "$tools/prepare_level.py" --source "$LEVEL_POWER_SOURCE" --archive /home/user/level-power-archive --out "$skew" --reference-level "$base"
python3 "$tools/compare_level_worlds.py" "$base" "$skew"
run_native "$skew" power-cycle
status=0
python3 "$tools/evaluate_level.py" "$skew" power-cycle || status=1
for name in cold write receiver-idle receiver-write receiver-out-of-range lead-12 lead-55 lead-95 lead-157; do
 run_native "$skew" "$name"
 case "$name" in
  receiver-*) ;;
  *) python3 "$tools/evaluate_level.py" "$skew" "$name" || status=1;;
 esac
done
python3 "$tools/evaluate_level.py" "$skew" receiver-idle || status=1
printf 'measured_status=%d\n' "$status"
exit "$status"
