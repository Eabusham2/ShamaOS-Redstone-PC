# Held POWER request at 35/35 redstone ticks

The saved four-word fixture captured the POWER lever with 12, 55, 95 and 157 redstone ticks (RT) of lead before the first raw edge. Holding the request high removed the archived edge-history circuit’s lost 12 RT startup. Three existing repeaters on the power register’s private clock branch also had to change to satisfy the 8 RT setup and 2 RT hold requirements during shutdown. The level-request circuit with the original route reproduces a 1 RT setup failure at tick 15,333.

| Register | Original level-request route, minimum setup / hold (RT) | Retimed route, minimum setup / hold (RT) |
| --- | --- | --- |
| Power hold | 1 / 34 | 8 / 27 |
| Divided clock mode | 19 / 2 | 13 / 2 |
| Reset pulse request | 39 / 9 | 39 / 12 |
| Returned reset receipt | 38 / 32 | 38 / 32 |

Both entries use fresh Java 1.20.4 worlds and the same pinned terrain-aware MCHPRS binary. The timing requirements apply at the physical clock and data inputs of the mapped redstone DFF template. Each of the six cache registers also passed the local aperture checks. The original level-only route is retained as a failing control, including its exact per-tick D and C traces.

## Physical change and geometry

The unretimed shutdown edge was sampled at tick 15,333 with 1 RT setup and 4,473 RT hold. Moving the private clock branch by 7 RT put the same event at tick 15,340 with 8 RT setup and 4,466 RT hold.

The source patch applies to research revision `370c24df4db7de1d9d34dec6272f40bb90e49a34` from the public startup research archive. The recovered RTL SHA-256 is `1469fc1fde66b9722c4e0add68276da325296d964d51d57bef219fb9e1b5eb4c`. The Yosys 0.33 read partition interfaces as black boxes before mapping the shell using the production mapping commands. The cache is the hash-verified archived real adapter graph. The resulting startup and cache write cone contains 177 mapped cells, 479,052 assigned blocks, four mixed 32-bit words and 4,566 Anvil chunks. `mapping/map-shell.ys` preserves the exact shell procedure.

Both native worlds use the same map and the same 160 RT stress delay on the final write guard’s reset branch. The power clock adjustment changed only three north-facing repeaters. Their positions are (1680, −31, 339), (1680, −31, 348) and (1680, −31, 358). Their delays changed from 1/1/1 to 4/4/2 RT. The physical emitter confirmed that the raw-clock branch belongs exclusively to the power register’s C pin. A record-by-record comparison of both exported streams found these three block-state differences across all 109,719 records. Both Anvil worlds, region fingerprints, exact native streams and raw traces are included.

## What the native cases exercised

- All 128 preloaded bits survived cold initialization through 1,537 RT. The real host-write calibration ran for 409,600 RT, wrote zero to row zero and retained the other three 32-bit words. Physical row-write intervals were 205428–221811 and 328308–344691 RT.
- The nominal lifecycle ran for 26,812 RT with 69,680 scenario assertions. All seven startup, manual reset, shutdown and stale-acknowledgment checkpoints matched. Each of 136 generated highs was 35 RT wide at the source and at every cache clock pin, entirely within the appropriate local reset windows. The native trace includes seven gate output signals. All 128 storage bits and the real write and commit lines were checked on every tick.
- The idle, early valid-write and early out-of-range-write cases each ran 15,866 RT. All six receiver DFFs received 17 complete nominal raw pulses while their individual reset qualifiers were asserted. No register advanced before the deliberate divided edge. The first divided edge produced the expected accepted/rejected state.
- The 12, 55, 95 and 157 RT lead cases each started with an early host write, with address 0x1000 for the 95 RT case and address zero for the others. Every case retained one continuous hold and divided-mode interval, passed all ten local register aperture measurements, and captured the expected write-enable/state bits at the first deliberate divided edge. The tested leads are discrete stimulus values.

The divided clock input and core-gate signal are exposed fixture boundaries. Clock distribution in the complete computer, console-to-shell differential route delay, the full divider, whole-system timing and full computer boot remain open. The private repeater settings depend on this physical placement and routing.

## Shutdown and restored memory

After the physical row write, the engine ran an actual 417,248 RT shutdown workload and wrote a quiescent snapshot with zero pending scheduled events. The restored Anvil world independently reproduced all 4,570 live chunks, 109,680 sections, 5,158,734 occupied blocks and 133 analog comparator entities. This included the original 4,566 chunks and four additional chunks the engine touched. Direct block-state readback recovered the four words as 00000000, 12345678, 11223344 and ABCDEF01. The snapshot SHA-256 is `77ed75be25f32667e1e293188f51472040811fd92ff73298e28406968e01eb12`.

The unchanged restored world was re-exported as `b53cc0d75cf90f642666b877030a4b6577957415025866563005bdd533b3db31`. The first attempted native restart was rejected during scenario validation, before any tick executed. Both the static core-gate input and shutdown acknowledgment were genuinely saved as energized external redstone blocks. This pinned runner requires every declared mutable external drive pad to start as air. The original scenario, native error and per-pad classification are included in the archive. The stored words and quiescent native restore are verified. A repeated restart using a physical toggleable acknowledgment is a separate measurement.

The recovered persistence driver first attempted the construction writer’s ledger check against the snapshot. The measured driver checks the snapshot-specific independent native readback receipt, its parent stream/scenario and all counts, then directly reads the 128 Anvil storage blocks. Both harness versions are included.

## Verify

Run `python3 verify_measurements.py measurements.zip` with Python 3.11 or newer to verify every archived file and recompute the retained register apertures from the actual local native traces. The archive preserves all three saved worlds, the actual native inputs and underlying engine outputs, both raw streams, the quiescent snapshot, and its re-exported stream. The production shell and whole-machine release remain unchanged by this study.
