"""Reconstruct the private +7 RT power-register C trial on the level-request world.

The routine is recovered from the original authoring command. The local C/D
waveforms and shutdown snapshot for this retiming still need to be measured.
"""
import json
from pathlib import Path

def retime_power_clock(tile, cells, produced, reference_world, receipt_file):
    from shamaos.worldio import NativeWorldReader, canonical_block_state
    from shamaos.model import BlockState

    reference = NativeWorldReader(Path(reference_world))
    dff, = [name for name, cell in cells.items()
            if cell["connections"].get("Q") == [produced["clock_hold"]]]
    net, = [route for route in tile.physical.nets
            if route.bit == cells[dff]["connections"]["C"][0]]
    sink, = [contact for contact in net.sinks if (contact.name, contact.pin) == (dff, "C")]
    lo, hi = sorted((tile.track_base_z + 4 * tile.tracks[net.bit] + 4,
                     tile.escapes[sink.pos].escape_z - 6))
    remaining = 7
    changes = {}
    for block in tile.endpoint_route(net, sink)[1]:
        if (block.pos.y != tile.branch_y or not lo < block.pos.z < hi
                or block.block.name != "minecraft:repeater"):
            continue
        old = reference.get_block(block.pos)
        assert old == canonical_block_state(tile.overrides.get(block.pos, block.block))
        properties = dict(old.properties)
        add = min(remaining, 4 - int(properties["delay"]))
        if not add:
            continue
        new = BlockState.of(old.name, **(properties | {"delay": str(int(properties["delay"]) + add)}))
        changes[block.pos] = old, new
        remaining -= add
        if not remaining:
            break
    assert not remaining
    owners = {pos: set() for pos in changes}
    for route in tile.physical.nets:
        for end in (route.source, *route.sinks):
            for block in tile.endpoint_route(route, end)[1]:
                if block.pos in owners:
                    owners[block.pos].add((route.bit, end.name, end.pin))
    assert all(value == {(net.bit, dff, "C")} for value in owners.values())
    receipt = {
        "owner": [net.bit, dff, "C"],
        "power_C": [{"pos": [pos.x, pos.y, pos.z], "old": dict(old.properties),
                     "new": dict(new.properties)} for pos, (old, new) in changes.items()],
    }
    Path(receipt_file).write_text(json.dumps(receipt, indent=2) + "\n")
    for pos, (old, new) in changes.items():
        tile.overrides[pos] = new
    return receipt
