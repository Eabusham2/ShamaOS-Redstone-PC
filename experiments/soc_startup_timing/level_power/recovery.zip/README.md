# Level-request power experiment recovery

The research shell samples the POWER lever as a continuing request and keeps the powered-state register active until shutdown completes. In the original saved four-word cache experiment, this captured the 12 RT lead that the archived edge-history circuit lost. The level-request circuit still failed its 8 RT setup requirement at the power register. The private +7 RT power-clock change and switched-off save/reopen workload have no completed native result in this recovery package.

## Source identity

The published startup archive at main commit `f747dba089f0b750ab07d7f2c70a7992d7e04747` contains the base research Git bundle. Its verifier checked 124 payloads, 25 native bindings and 107 files against the extracted research revision `370c24df4db7de1d9d34dec6272f40bb90e49a34`. The level-request patch applies to that exact revision. The recovered RTL file matched its SHA-256 recorded before the interrupted session. The reconstructed Git tree is `10b2a72eb3ad6e27ced35fd8ab66a374a7e7e221`. The earlier scratch commit was recorded as `34a3ea6e40127905fe2564aba10839746c96ea47`; the original commit metadata was unavailable during reconstruction.

| Recovered file | SHA-256 |
| --- | --- |
| rtl/shama_soc.sv | 1469fc1fde66b9722c4e0add68276da325296d964d51d57bef219fb9e1b5eb4c |
| tests/test_soc_startup_clock.py | 2c7ded39af633927395eb9d926b7fd1b5f2461b9629bcae45e5e38f8e447f300 |
| tools/prove_soc_cold_clock.py | 9c477f6e9c69523a9158563e2709849946efcc8cde7acdc725aea4200a29924c |
| level-request.patch | 8d7ac9808a518068e504eda45d43b10a1cf6f0179c770b144724cfb76ddc191f |

The published archive and the three-file patch reproduce the source. From a checkout of that main commit, extract the archive with `python3 experiments/soc_startup_timing/verify.py --extract /tmp/level-archive`, fetch the archived `source/research.bundle` using the command in its README, and check out research revision `370c24d` in a separate worktree. Re-run the archive verifier with `--source` before applying `git apply /path/to/level-request.patch`. Verify the three hashes above after applying the patch.

## Reported original observations

The pre-interruption native execution used MCHPRS revision `f9e10d2572116bf5dcb9a36a305f28e40641a61a` and terrain runner SHA-256 `c8032089622501cb57f9edbb0ea7e3be24e3a23fd0b2b80653b0ed4f07045610`. The raw level-request traces and Anvil files from that execution could not be recovered. The values in this section were recorded during the original execution and await independent replay. The storage fixture had 177 mapped cells, four physical 32-bit words, 479,052 assigned blocks, 4,566 chunks and 14 regions. The old native level-only input stream SHA-256 was `adbcd739877a8d201c5f1d4ffe8ae48627c64ba89cd2847f399d2a48ad3468b9`.

| Original level-request case | Recorded result |
| --- | --- |
| Cold and host write | All 128 bits survived 1,537 cold ticks. In 409,600 write ticks, the row pulses were 205428–221811 and 328308–344691. The other three words kept their preloads. |
| Nominal power lifecycle | Seven checkpoints matched. All 136 generated highs lasted 35 RT within reset. The power-register edge at tick 15,333 had 1 RT setup. Its observed hold was 4,473 RT. Whole-trace power setup/hold minima were 1/34 RT. |
| Other shell registers | The divided-mode, reset-request and reset-receipt minimum setup/hold pairs were 19/2, 39/9 and 38/32 RT respectively. |
| Receiver profiles | Idle, early valid write and out-of-range write each completed 15,866 ticks. Each legal first divided edge selected the expected receiver state. |
| POWER lead | Leads of 12, 55, 95 and 157 RT all entered a single held and divided-mode interval. The 95 RT case used address 0x1000. The others used address zero. |
| Private power C +7 RT | The independently read back second world differed at exactly three existing repeaters. Every other state in its 109,719 exported records matched its level-only reference. A native lifecycle attempt ended during world import, before a timing result was written. |
| Switched-off save and reopen | The driver was syntax checked. Its native snapshot, Anvil restore and fresh-engine restart were pending. |

The earlier canonical full-shell Yosys invocation was killed twice while reading a module later blackboxed. An interface-first Yosys 0.33 run read the original partition interfaces as libraries and the shell normally, then used the original production hierarchy, blackboxes and gate mapping. On the original shell the two methods produced distinct whole-shell counts (6,964 canonical, 6,967 interface-first). The original 181-cell fixture had identical primitive positions, probe positions, tracks and endpoint sets, all 460,438 routed operations, emitted local cell block states and 160 RT private reset branch. This validation applies to the measured original fixture. The level-request shell was mapped using the interface-first route and had 6,963 shell cells.

## Recovery scripts and next measurements

`retime_original_fragment.txt` preserves the C+7 code recovered from its authoring call. `retime_power_clock.py` exposes that selection as a callable with explicit paths. Every changed repeater must already exist in the Java world and belong exclusively to the branch ending at the physical clock-hold DFF's C pin. The original 160 RT stress on the write guard's reset arm is retained. `prepare_level.py` is a newly reconstructed driver, syntax checked at packaging time. It verifies the source inventory and original cache graph, builds the two Java worlds, and rebinds the archived stimuli to the current actual pin positions. `persist_level.py` was recovered from the authored save/reopen workload with a configurable research-source path. The scripts have their own digests in SHA256SUMS. None of these recovery files modifies production.

Run heavy jobs serially. In the recovered environment, the verified parent source, archived evidence and toolchain are at `/home/user/level-power-recovery`, `/home/user/level-power-archive` and `/home/user/shama-test-tools/env.sh`. Use fresh, separate output paths.

```sh
. /home/user/shama-test-tools/env.sh
export OPENBLAS_NUM_THREADS=1
export LEVEL_POWER_SOURCE=/home/user/level-power-recovery
archive=/home/user/level-power-archive
tools=/home/user/level-power-evidence
level=/home/user/level-replay
skew=/home/user/level-c7-replay
python3 "$tools/prepare_level.py" --source "$LEVEL_POWER_SOURCE" --archive "$archive" --out "$level"
python3 "$tools/prepare_level.py" --source "$LEVEL_POWER_SOURCE" --archive "$archive" --out "$skew" --reference-level "$level"
"$SHAMA_MCHPRS_TERRAIN_RUNNER" "$skew/world.jsonl" "$skew/power-cycle.json" 4694 > "$skew/power-cycle-result.json"
```

Check every actual C and D of all four shell timing registers and six receiver DFFs. Measure setup of at least 8 RT and hold of at least 2 RT on every eligible rising edge. Confirm all seven lifecycle states, 136 full 35 RT source highs under reset, the delivered raw and divided highs, the local reset qualifiers, and the continuous 128-bit storage and commit-line assertions. Run cold, write, receiver-idle, receiver-write, receiver-out-of-range and lead-12/55/95/157 in a separate fresh import for each. Passing the engine's continuous assertions alone does not establish local timing.

```sh
PERSIST_STOP=snapshot python3 "$tools/persist_level.py" "$skew"
PERSIST_STOP=restore python3 "$tools/persist_level.py" "$skew"
python3 "$tools/persist_level.py" "$skew"
```

Verify a zero pending-tick count prior to snapshot, snapshot digest, persisted high shutdown acknowledgment and deasserted POWER pads. Read back the changed row as zero and the other words as 0x12345678, 0x11223344 and 0xABCDEF01 from the saved Anvil blocks. Inspect every reported state checkpoint and local timing result on both short-lead restarts, the core-high widths and reset coverage, and the absence of row-write or pending-write intervals. The recovered persistence driver writes these final classifications to `persistence/summary.json`; its exit status alone does not validate them.
