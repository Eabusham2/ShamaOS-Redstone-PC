"""Regenerate the bounded source-specific geometry and native inputs from retained sources.

Build the level-only fixture first. Use --reference-level on a new directory for
the private C retiming. Shell mapping is explicitly interface-first Yosys 0.33.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from unittest.mock import patch

from retime_power_clock import retime_power_clock


def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--reference-level", type=Path)
    args = parser.parse_args()
    source, archived, out = [p.resolve() for p in (args.source, args.archive, args.out)]
    sys.path[:0] = [str(source / folder) for folder in ("src", "tools", "tests")]
    import prove_soc_cold_clock as proof
    from shamaos.synthesis import _quote_yosys, _portable_mapping, _abc_supports_fast
    from shamaos.hardware.logic import template_for
    from shamaos.hardware.partition_planner import load_mapped_module
    from shamaos.system_build import SOC_RTL_FILES, PARTITION_SPECS

    manifest = read(archived / "manifest.json")
    assert manifest["source_commit"] == "370c24df4db7de1d9d34dec6272f40bb90e49a34"
    def checked_archived(relative):
        file = archived / relative
        assert digest(file) == manifest["files"][relative]["sha256"], relative
        return file

    original = read(checked_archived("final/35/source-hashes.json"))
    signed = proof.source_hashes()
    changes = {
        "rtl/shama_soc.sv": "1469fc1fde66b9722c4e0add68276da325296d964d51d57bef219fb9e1b5eb4c",
        "tools/prove_soc_cold_clock.py": "9c477f6e9c69523a9158563e2709849946efcc8cde7acdc725aea4200a29924c",
    }
    assert signed == original | changes, "research sources do not match the recovered source inventory"
    assert digest(source / "tests/test_soc_startup_clock.py") == "2c7ded39af633927395eb9d926b7fd1b5f2461b9629bcae45e5e38f8e447f300"
    out.mkdir(exist_ok=False, parents=True)
    save(out / "source-hashes.json", signed)
    if args.reference_level is None:
        yosys = shutil.which("yosys")
        version = subprocess.check_output([yosys, "-V"], text=True)
        assert "0.33" in version and "2584903a060" in version, version
        rtl = source / "rtl"
        shell = rtl / "shama_soc.sv"
        interfaces = [source / relative for relative in SOC_RTL_FILES if (source / relative) != shell]
        script = [
            "read_verilog -lib -sv -I " + _quote_yosys(rtl) + " " + " ".join(map(_quote_yosys, interfaces)),
            "read_verilog -sv -I " + _quote_yosys(rtl) + " " + _quote_yosys(shell),
            "hierarchy -check -top shama_soc",
            "blackbox " + " ".join(top for instance, top in PARTITION_SPECS),
            _portable_mapping((source / "synth/redstone.ys").read_text(), fast=_abc_supports_fast(yosys)),
            "write_json " + _quote_yosys(out / "shell.json"),
        ]
        script_file = out / "map-shell.ys"
        script_file.write_text("\n".join(script) + "\n")
        with (out / "shell-yosys.log").open("w") as log:
            subprocess.run([yosys, "-s", str(script_file)], cwd=source, stdout=log, stderr=log, check=True)
        shutil.copyfile(checked_archived("final/35/cache.json"), out / "cache.json")
    else:
        reference = args.reference_level.resolve()
        assert read(reference / "source-hashes.json") == signed
        for filename in ("shell.json", "cache.json"):
            shutil.copyfile(reference / filename, out / filename)
        assert digest(out / "cache.json") == digest(checked_archived("final/35/cache.json"))

    # The two real JSON netlists are already materialized. Run the candidate's
    # original pin translation, cone selection, physical placement and routing.
    def mapped(sources, *, top, output_json, **unused):
        assert (top, output_json.name) in {("shama_soc", "shell.json"), ("shama_cache_adapter", "cache.json")}
        assert output_json.is_file()
        return output_json
    with patch.object(proof, "synthesize_json", mapped):
        tile, cells, produced = proof.map_fixture(out, False)
    assert len(cells) == 177
    shell_module, _ = load_mapped_module(out / "shell.json", "shama_soc")
    assert len(shell_module["cells"]) == 6963
    assert "power_previous" not in shell_module["netnames"]
    assert shell_module["cells"]["keep_power"]["connections"]["B"] == shell_module["ports"]["power_switch"]["bits"]
    if args.reference_level is not None:
        assert digest(out / "joined.json") == digest(reference / "joined.json")
        retime_power_clock(tile, cells, produced, reference / "world", out / "private-power-C.json")
    readback, probes = proof.make_world(out, tile, cells, produced, 160)
    save(out / "readback.json", readback)
    save(out / "probes.json", probes)
    assert (readback["assigned_blocks"], readback["chunks"]) == (479052, 4566)
    inputs = {name: proof.point(proof.west_driver(port[0])) for name, port in tile.physical.input_ports.items()}
    timing = proof.power_register_probes(tile, cells, out / "shell.json")
    receivers = proof.receiver_pins(tile, cells, out / "cache.json", produced)
    joined = {**probes, **timing, **receivers.probes}
    # Output probes are read-only engine coordinates and add no placed geometry.
    for name, cell in cells.items():
        if not name.startswith("shell_") or cell["type"] not in ("CLOCK_GUARD", "CLOCK_GUARD_ACK", "CLOCK_OR", "WRITE_GUARD"):
            continue
        for pin in ("Y", "Q"):
            if pin in cell["connections"]:
                delta = template_for(cell["type"]).pins[pin]
                point = tile.physical.cell_origins[name].offset(delta.x, delta.y, delta.z)
                joined["gate_" + name + "_" + pin] = proof.point(point)
    for key in ("cold", "write", "power-cycle", "receiver-idle", "receiver-write", "receiver-out-of-range",
                "lead-12", "lead-55", "lead-95", "lead-157"):
        if key.startswith("lead-"):
            lead = key.split("-")[1]
            old = "power-lead/" + lead + ("-12.json" if lead == "95" else "-None.json")
        else:
            old = "final/35/" + key + ".json"
        case = read(checked_archived(old))
        assert not (case["inputs"].keys() - inputs.keys())
        case["inputs"] = {label: inputs[label] for label in case["inputs"]}
        if key == "cold" or key == "write":
            case["outputs"] = {label: probes[label] for label in case["outputs"]}
        else:
            case["outputs"] = joined
            if key == "power-cycle" or key.startswith("lead-"):
                case["trace_outputs"] = list(dict.fromkeys(
                    [name for name in case["trace_outputs"] if not name.startswith("timing_power_previous_")]
                    + list(timing) + list(receivers.probes) + [name for name in joined if name.startswith("gate_")]
                ))
        save(out / (key + ".json"), case)
    receipt = {
        "mapped_files": {n: digest(out / n) for n in ("shell.json", "cache.json", "joined.json")},
        "stream_sha256": digest(out / "world.jsonl"),
        "assigned_blocks": readback["assigned_blocks"],
        "chunks": readback["chunks"],
        "raw_clock_half_period_rt": 35,
        "first_independent_native_replay_pending": True,
        "native_timing_verified": False,
    }
    save(out / "preparation.json", receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
