`timescale 1ns/1ps

module tb_soc_startup_clock;
    localparam integer HALF = 10;
    logic clk = 0, power_switch = 0, reset_button = 0;
    logic clock_hold;
    shama_soc #(.CORE_DIV_BIT(1)) dut(
        .clk, .power_switch, .reset_button, .clock_hold,
        .pause_switch(1'b0), .step_button(1'b0), .controller(10'd0),
        .kb_rows(8'd0), .kb_cols(8'd0), .ram_selected_word(32'd0),
        .flash_selected_word(32'd0), .cache_selected_word(32'd0),
        .vram_selected_word(32'd0), .display_row_ready(1'b1)
    );

    wire [3:0] writes = {dut.cache_write_commit, dut.ram_write_commit,
                         dut.flash_write_commit, dut.vram_write_commit};
    integer core_rises = 0;
    time last_rise;
    always @(posedge dut.core_clk) begin
        core_rises++;
        last_rise = $time;
    end
    always @(negedge dut.core_clk) begin
        if (core_rises && $time - last_rise < HALF)
            $fatal(1, "truncated core high phase, width %0t", $time - last_rise);
    end

    task automatic check_reset;
        if (dut.rst !== 1 || writes !== 4'b0000)
            $fatal(1, "expected reset and all four writes inhibited");
    endtask

    // With power and hold both off the physical clock emits no raw edges.
    // Starts and stops in this test preserve its complete high and low phases.
    task automatic first_reset_pulse;
        clk = 1;
        #1;
        check_reset();
        if (dut.core_clk !== 1 || clock_hold !== 1)
            $fatal(1, "power-on did not deliver the high phase under reset");
        #(HALF - 1);
        clk = 0;
        #1;
        if (dut.core_clk !== 0 || dut.rst !== 0)
            $fatal(1, "power-on did not release reset in the low phase");
        if ({dut.debug_app, dut.debug_cache_used, dut.u_cpu.regs[8],
             dut.u_cpu.regs[11], dut.debug_fault, dut.halted, dut.input_overflow} !== '0)
            $fatal(1, "console fields differ from the actual post-reset state");
        if (dut.u_services.copy_source_flash !== 1)
            $fatal(1, "service register requiring a nonzero reset was not set");
        #(HALF - 1);
    endtask

    initial begin
        dut.powered=0; dut.power_previous=0; dut.core_div_counter=0; dut.core_gate=0;
        dut.u_services.shutdown_ready=0;
    end
    integer before_rises;
    initial begin
        #HALF;
        if (clock_hold !== 0 || core_rises != 0)
            $fatal(1, "idle power unexpectedly started the clock");
        check_reset();
        power_switch = 1;
        #HALF;
        first_reset_pulse();

        // The second subsequent raw rise starts the divide-by-four clock.
        before_rises = core_rises;
        repeat (4) begin
            clk = 1; #HALF; clk = 0; #HALF;
        end
        if (core_rises != before_rises + 1)
            $fatal(1, "normal divided clock failed after startup");

        // Press reset midway through a raw high phase, then release it midway
        // through a later raw high. The release must preserve the whole pulse.
        clk = 1; #(HALF/2); reset_button = 1; #1;
        check_reset();
        #(HALF/2 - 1); clk = 0; #HALF;
        clk = 1; #(HALF/2); reset_button = 0; #1;
        check_reset();
        if (dut.core_clk !== 1)
            $fatal(1, "manual reset release clipped the raw high phase");
        #(HALF/2 - 1); clk = 0; #HALF;
        if (dut.rst !== 0 || dut.core_clk !== 0)
            $fatal(1, "manual reset did not release in the low phase");

        // Model the service's clean-shutdown acknowledgment. Real firmware
        // exercises the filesystem and cleanup in the longer SoC lifecycle.
        // Stop after the last whole pulse. No always-running testbench clock
        // can clear shutdown_ready for us before the next power-on request.
        power_switch = 0;
        dut.u_services.shutdown_ready = 1;
        clk = 1; #HALF; clk = 0; #HALF;
        if (clock_hold !== 0 || dut.shutdown_ready !== 1)
            $fatal(1, "failed to exercise stopped clock with outstanding acknowledgment");
        check_reset();
        power_switch = 1;
        #HALF;
        first_reset_pulse();
        if (dut.shutdown_ready !== 0)
            $fatal(1, "new power-on failed to clear old acknowledgment");
        $display("SOC STARTUP CLOCK PASS");
        $finish;
    end
endmodule
