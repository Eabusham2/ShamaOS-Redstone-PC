module reference_18(input clk,rst,output [17:0] value); reference_counter #(.WIDTH(18)) impl(clk,rst,value); endmodule
