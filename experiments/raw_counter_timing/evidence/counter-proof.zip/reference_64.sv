module reference_64(input clk,rst,output [63:0] value); reference_counter #(.WIDTH(64)) impl(clk,rst,value); endmodule
