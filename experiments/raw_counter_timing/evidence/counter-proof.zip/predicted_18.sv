module predicted_18(input clk,rst,output [17:0] value); predicted_counter #(.WIDTH(18)) impl(clk,rst,value); endmodule
