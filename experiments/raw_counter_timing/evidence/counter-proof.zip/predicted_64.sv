module predicted_64(input clk,rst,output [63:0] value); predicted_counter #(.WIDTH(64)) impl(clk,rst,value); endmodule
