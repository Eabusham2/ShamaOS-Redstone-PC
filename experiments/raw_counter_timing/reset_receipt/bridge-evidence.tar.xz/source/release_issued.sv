`include "shama_native_cells.svh"
module shama_counter_release(
    input wire raw, local_reset, cleared_valid, cleared_ticket,
    output wire reset, output reg request_ticket = 0, output reg released = 0
);
    reg issue = 0;
    wire release_clock;
    wire reply_matches = cleared_valid && cleared_ticket == request_ticket;
    always @(posedge raw) issue <= local_reset && released;
    always @(posedge issue) request_ticket <= !request_ticket;
    CLOCK_GUARD update_release(.A(raw), .B(!(issue || (!local_reset && reply_matches))), .Y(release_clock));
    always @(posedge release_clock) released <= !issue;
    assign reset = local_reset || issue || !released;
endmodule
