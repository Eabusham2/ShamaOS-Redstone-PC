from pathlib import Path
import json,os,subprocess
from shamaos.hardware.partition_planner import Graph,build_plan
from shamaos.hardware.bounded_facade import place_with_egress
from shamaos.bounded_system import BoundedPartition
from shamaos.hardware.logic import template_for
from experiments.raw_counter_timing.neighbor_carry.receiver.check_stream import rising,transitions,apertures
d=Path(os.environ.get('BRIDGE_OUT','/tmp/phase-clear-bridge/issued'));q=json.loads((d/'cold.json').read_bytes());m=json.loads((d/'bridge.json').read_bytes())['modules']['shama_counter_release']
g=Graph.read(d/'bridge.json','shama_counter_release');p=build_plan(g,cell_budget=64,boundary_budget=128,domain_budget=128,arity=4);v=place_with_egress(g,p,surface_y=-61,maximum_y=285);pt=BoundedPartition.from_placed(d/'bridge.json','shama_counter_release',p,v)
bit=m['netnames']['issue']['bits'];ff,=[n for n,c in m['cells'].items() if c['connections'].get('Q')==bit];origin=pt.cell_origins[ff]
for name,o in template_for('DFF').pins.items():i=origin.offset(o.x,o.y,o.z);q['outputs']['issue_'+name]=[i.x,i.y,i.z]
t0=sum(s['ticks'] for s in q['steps']);raw0=t0+210;events={};phases=[]
def ev(t,**args): events.setdefault(t,{}).update(args)
for i in range(70):
 start=raw0+(i*48+4)*70+i;nextval=bool((i+1)%2);correct=start+2450
 ev(start,local_reset=True);ev(start+700,local_reset=False);ev(start+1050,cleared_valid=True);ev(correct,cleared_ticket=nextval)
 ev(start+2900,cleared_valid=False)
 phases.append((start,correct,nextval))
last=phases[-1][0]+3280
for t in range(raw0,last,70):ev(t,raw=True);ev(t+35,raw=False)
order=sorted(events);q['steps'].extend([{'ticks':order[0]-t0}]+[{'ticks':b-a,'drive':events[a]} for a,b in zip(order,order[1:])])
q['steps'].append({'ticks':2000,'drive':events[order[-1]],'expect':{'port_raw':False,'released':True,'request_ticket':False}})
case=d/'matrix.json';case.write_text(json.dumps(q));out=d/'matrix-result.json'
with out.open('wb') as fp:subprocess.run([os.environ['SHAMA_MCHPRS_TERRAIN_RUNNER'],d/'world.jsonl',case,'1200'],stdout=fp,check=True)
r=json.loads(out.read_bytes());w=r['traces'];bad=[];window=[]
for i,(start,correct,val) in enumerate(phases):
 t=transitions(w['request_ticket_Q']);rises=[t0 for t0 in t if start<t0<start+3200]
 if len(rises)!=1 or bool(w['request_ticket_Q'][rises[0]])!=val:bad.append(('ticket',i,rises))
 # The actual external reset must remain high during stale-ack contact.
 if (not all(w['reset'][start+550:correct]) or not all(w['released_Q'][start+3000:start+3200])):bad.append(('earliness',i))
 window.append(rises)
ap={k:apertures(w[k+'_C'],w[k+'_D']) for k in ('released','request_ticket','issue')}
p={'transactions':70,'bad':bad,'ap':ap,'pending':r['pending_ticks_after_scenario'],'world':r['imported_stream_sha256'],'issued':window}
(d/'matrix-review.json').write_text(json.dumps(p,indent=2));print('bad',bad,'margins',[(k,x['setup'],x['hold'],len(x['violations'])) for k,x in ap.items()],flush=True)
