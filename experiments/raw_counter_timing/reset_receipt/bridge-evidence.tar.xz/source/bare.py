from pathlib import Path
import os,json,subprocess
from shamaos.hardware.partition_planner import Graph,build_plan
from shamaos.hardware.bounded_facade import place_with_egress
from shamaos.bounded_system import BoundedPartition
from shamaos.hardware.logic import template_for
from shamaos.synthesis import synthesize_json
from shamaos.mchprs_import import export_world
from shamaos.worldio import NativeWorldWriter
from experiments.raw_counter_timing.neighbor_carry.receiver.check_stream import rising,transitions,apertures
dest=Path(os.environ.get('BRIDGE_OUT','/tmp/phase-clear-bridge/bare'));dest.mkdir(exist_ok=True)
source=Path(os.environ.get('BRIDGE_SOURCE','/tmp/shama-counter-clear-protocol/release.sv'))
top='shama_counter_release';mapped=dest/'bridge.json'
synthesize_json([source],repo_root=Path.cwd(),top=top,output_json=mapped)
g=Graph.read(mapped,top);plan=build_plan(g,cell_budget=64,boundary_budget=128,domain_budget=128,arity=4)
placed=place_with_egress(g,plan,surface_y=-61,maximum_y=285);p=BoundedPartition.from_placed(mapped,top,plan,placed)
module=json.loads(mapped.read_bytes())['modules'][top]
def tup(v):return [v.x,v.y,v.z]
pins={k:tup(v[0]) for k,v in p.input_ports.items()};obs={k:tup(v[0]) for k,v in p.output_ports.items()}
for k in ('released','request_ticket'):
 bit=module['ports'][k]['bits'];ff,=[n for n,c in module['cells'].items() if c['connections'].get('Q')==bit];o=p.cell_origins[ff]
 for name,v in template_for('DFF').pins.items():obs[k+'_'+name]=tup(o.offset(v.x,v.y,v.z))
stream=dest/'world.jsonl'
if not stream.exists():
 with NativeWorldWriter(dest/'world',surface_y=-61,spawn_platform=False) as w:w.set_blocks(p.iter_placements());assert w.validate()['status']=='passed'
 export_world(dest/'world',stream)
q={'inputs':pins,'outputs':obs|{'port_'+k:v for k,v in pins.items()},'initial_ticks':0,'capture_trace':True,'steps':[]}
def hold(n,**vals):q['steps'].append({'ticks':n,'drive':vals})
def pulses(n):
 for _ in range(n):hold(35,raw=True);hold(35,raw=False)
hold(1100,local_reset=True);pulses(15);hold(220,local_reset=False);pulses(19)
hold(160,cleared_valid=True);pulses(25);hold(140,cleared_valid=False);pulses(12);hold(1400)
prior=len(q['steps']);q['steps'][-1]['expect']={'released':True,'reset':False,'request_ticket':False}
case=dest/'cold.json';case.write_text(json.dumps(q))
with (dest/'cold-result.json').open('wb') as out:subprocess.run([os.environ['SHAMA_MCHPRS_TERRAIN_RUNNER'],stream,case,'1200','--snapshot',dest/'cold-snapshot.jsonl'],stdout=out,check=True)
del q['steps'][-1]['expect']
hold(11,local_reset=True);pulses(25);hold(20,local_reset=False,cleared_valid=True);pulses(23);hold(1400)
q['steps'][-1]['expect']={'reset':True,'released':False,'request_ticket':True}
hold(140,cleared_ticket=True);pulses(20);hold(1400)
q['steps'][-1]['expect']={'released':True,'reset':False,'request_ticket':True}
case=dest/'repeat.json';case.write_text(json.dumps(q))
with (dest/'repeat-result.json').open('wb') as out:subprocess.run([os.environ['SHAMA_MCHPRS_TERRAIN_RUNNER'],stream,case,'1200'],stdout=out,check=True)
for st in ('cold','repeat'):
 r=json.loads((dest/(st+'-result.json')).read_bytes());w=r['traces'];print(st,g.cell_count,p.bounds,{n:{'Qedges':transitions(w[n+'_Q']),'CDC':apertures(w[n+'_C'],w[n+'_D']) if rising(w[n+'_C']) else None} for n in ('released','request_ticket')},r['pending_ticks_after_scenario'],flush=True)
