// Coherent raw sample, edge decode, Shift and immutable slow-domain epoch payload.
// All signals are still in the raw clock domain. Storage and crossing are separate.
module qualified_capture #(parameter REGISTERED_CONSOLE_INPUTS=1, parameter EXTERNAL_CONTROLLER_EDGES=1) (
    input wire clk, rst,
    input wire [7:0] kb_rows, kb_cols,
    input wire [9:0] controller,
    input wire [9:0] console_edge_word,
    input wire event_ack, observe,
    input wire [25:0] event_ack_data,
    output reg [9:0] levels, edges,
    output reg [5:0] key_index,
    output reg key_valid, key_shift, ack_rise, observed, sample_valid,
    output reg eventful, urgent_present,
    output reg [1:0] winning_urgent,
    output reg [25:0] ack_data
);
    wire [7:0] rows_q, cols_q;
    wire [9:0] control_q;
    reg [7:0] rows_prev, cols_prev;
    generate if (REGISTERED_CONSOLE_INPUTS) begin : external_sampler
        // These are the physical row, column and controller Q pins. Their
        // rising clock is also the edge that samples observe/ACK below.
        assign rows_q=kb_rows;
        assign cols_q=kb_cols;
        assign control_q=controller;
    end else begin : local_sampler
        reg [7:0] sampled_rows,sampled_cols;
        reg [9:0] sampled_controller;
        always @(posedge clk) begin
            sampled_rows<=kb_rows;
            sampled_cols<=kb_cols;
            sampled_controller<=controller;
        end
        assign rows_q=sampled_rows;
        assign cols_q=sampled_cols;
        assign control_q=sampled_controller;
    end endgenerate
    reg observe_q, decoded_observe;
    reg ack_q, ack_prev, q_valid, decoded_valid, toggle_shift, shift_state;
    reg [25:0] ack_qdata, decoded_ack_data;
    reg [9:0] decoded_levels, decoded_edges;
    reg [5:0] index_q;
    reg decoded_key, decoded_ack;

    function automatic onehot(input [7:0] x);
        case (x)
            8'h01,8'h02,8'h04,8'h08,8'h10,8'h20,8'h40,8'h80: onehot=1'b1;
            default: onehot=1'b0;
        endcase
    endfunction
    function automatic [2:0] encode(input [7:0] x);
        encode={|x[7:4], |(x & 8'hcc), |(x & 8'haa)};
    endfunction

    wire [9:0] current_edges;
    generate if (EXTERNAL_CONTROLLER_EDGES) begin : external_edges
        // The native previous-level and early edge registers keep clocking
        // during reset. The first current level after a reset starts a fresh
        // logical history, even when the controller was already held.
        reg previous_sample_valid;
        always @(posedge clk) previous_sample_valid<=!rst && q_valid;
        assign current_edges=previous_sample_valid ? console_edge_word : control_q;
    end else begin : local_edges
        reg [9:0] control_prev;
        always @(posedge clk) begin
            if(rst) control_prev<=0;
            else if(q_valid) control_prev<=control_q;
        end
        assign current_edges=control_q & ~control_prev;
    end endgenerate
    wire changed=(rows_q!=rows_prev || cols_q!=cols_prev);
    wire shift_key=(rows_q==8'h80 && cols_q==8'h80);
    always @(posedge clk) begin
        // A reset invalidates every older in-flight sample.
        if(rst) begin
            q_valid<=0; decoded_valid<=0; sample_valid<=0; shift_state<=0;
            rows_prev<=0;cols_prev<=0;ack_prev<=0;
        end else begin
            q_valid<=1;decoded_valid<=q_valid;sample_valid<=decoded_valid;
            if(q_valid) begin
                rows_prev<=rows_q;cols_prev<=cols_q;ack_prev<=ack_q;
            end
            if(decoded_valid && toggle_shift) shift_state<=!shift_state;
        end

        observe_q<=observe;decoded_observe<=observe_q;observed<=decoded_observe;
        ack_q<=event_ack;ack_qdata<=event_ack_data;
        decoded_key<=onehot(rows_q) && onehot(cols_q) && changed && !shift_key;
        toggle_shift<=shift_key && changed;
        index_q<={encode(rows_q),encode(cols_q)};
        decoded_levels<=control_q;decoded_edges<=current_edges;
        decoded_ack<=ack_q && !ack_prev;decoded_ack_data<=ack_qdata;

        // Register the exact record classifications beside their payload before fan-out.
        eventful<=(|decoded_edges) || decoded_key;
        urgent_present<=|decoded_edges[9:6];
        winning_urgent<={decoded_edges[8] || decoded_edges[9],
                         !decoded_edges[8] && (decoded_edges[9] || decoded_edges[7])};
        levels<=decoded_levels;edges<=decoded_edges;key_index<=index_q;
        key_valid<=decoded_key;key_shift<=shift_state;
        ack_rise<=decoded_ack;ack_data<=decoded_ack_data;
    end
endmodule
