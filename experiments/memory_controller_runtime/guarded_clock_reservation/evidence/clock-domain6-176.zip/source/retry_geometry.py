"""Replay the exact failed CI graph with extra real clock-route clearance."""
import hashlib
import json
from pathlib import Path
import resource
import time

from shamaos.hardware.cache_layout import place_compact_cache
from shamaos.hardware.partition_planner import Graph, audit_plan
from shamaos.hardware.partition_placement import audit_placement, balance_partition_clocks
from shamaos.hardware.bounded_facade import audit_egress
from tools.validate_connected_cache import manifest_cluster
from experiments.partition_placement.port_egress_manifest import write_egress_manifest, REQUIRED_SOURCE_BINDINGS

resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
out = Path('/tmp/shama-cache-ci-failure')
start = time.monotonic()
g = Graph.read(out / 'cache-validation/source/build/current/mapped.json', 'shama_cache_adapter')
print(json.dumps({'stage': 'placement', 'cells': g.cell_count, 'padding': 176}), flush=True)
try:
    plan, placed = place_compact_cache(g)
    report = {
        'status': 'passed', 'seconds': time.monotonic() - start,
        'scope': 'Controller placement and clock-matching only', 'source_mapped': g.source,
        'plan_audit': audit_plan(g, plan), 'placement_audit': audit_placement(g, plan, placed),
        'egress_audit': audit_egress(g, placed), 'clock_matching': balance_partition_clocks(plan, placed),
        'packing': placed.packing, 'unique_blocks': placed.unique_blocks,
        'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'complete_machine_runtime_verified': False,
    }
    (out / 'retry-176-plan.json').write_text(json.dumps(plan, indent=2))
    paths = (*REQUIRED_SOURCE_BINDINGS, 'src/shamaos/hardware/cache_layout.py', 'retry_geometry.py')
    sources = {}
    for name in paths:
        with Path(name).open('rb') as f:
            sources[name] = hashlib.file_digest(f, 'sha256').hexdigest()
    report['manifest'] = write_egress_manifest(out / 'retry-176-controller.json.gz', g, plan,
        manifest_cluster(placed), provenance={'source_hashes': sources, 'clock_balance_verified': True})
    (out / 'retry-176-report.json').write_text(json.dumps(report, indent=2, default=str))
    print(json.dumps(report, default=str), flush=True)
except BaseException as e:
    report = {'status': 'failed', 'seconds': time.monotonic() - start, 'type': type(e).__name__,
              'error': str(e), 'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    (out / 'retry-176-report.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report), flush=True)
    raise
