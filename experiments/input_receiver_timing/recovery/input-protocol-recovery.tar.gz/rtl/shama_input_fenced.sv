// The raw clock always captures physical pins. The slower worker accepts
// one step at a time and owns exactly one sealed, immutable packet bank.
module shama_input_fenced(
    input wire clk,rst,worker_step,
    input wire [7:0] kb_rows,kb_cols,input wire [9:0] controller,
    input wire request_token,request_ack,input wire [25:0] request_data,
    output reg response_token,output reg [36:0] response_data,
    output wire input_overflow,
    output reg [31:0] prefix_write,urgent_write,
    output reg [27:0] prefix_wdata,output reg [11:0] urgent_wdata,
    output wire [31:0] prefix_read,urgent_read,
    input wire [55:0] prefix_rdata,input wire [23:0] urgent_rdata,
    output reg [15:0] slot_write,output wire [15:0] slot_read,
    output reg [25:0] slot_wdata,input wire [25:0] slot_rdata
);
    `include "shama_input_keymap.svh"
    reg request_sync1,request_sync2,accepted;
    wire accept=request_sync2!=accepted && accepted==response_token;
    wire [9:0] levels,edges;
    wire [5:0] key_index;
    wire key_valid,key_shift,ack_rise,observed,sample_valid,eventful,urgent_present;
    wire [1:0] winning_urgent;
    wire [25:0] ack_data;
    shama_input_capture capture(.clk,.rst,.kb_rows,.kb_cols,.controller,.event_ack(accept&&request_ack),
        .observe(accept),.event_ack_data(request_data),.levels,.edges,.key_index,.key_valid,.key_shift,
        .ack_rise,.observed,.sample_valid,.eventful,.urgent_present,.winning_urgent,.ack_data);

    reg bank, open_ack, open_lost, sticky_hint, descriptor;
    reg [25:0] open_ack_data, sealed_ack_data;
    reg sealed_bank,sealed_ack,sealed_lost,sealed_shift;
    reg [9:0] sealed_levels;
    reg [16:0] prefix_ptr,urgent_ptr,sealed_prefix_end,sealed_urgent_end;
    wire fence=sample_valid && observed;
    wire current_bank=bank ^ fence;
    wire [16:0] prefix_at=fence ? 17'd1 : prefix_ptr;
    wire [16:0] urgent_at=fence ? 17'd1 : urgent_ptr;
    wire prefix_push=sample_valid && eventful && !prefix_at[16];
    wire saturated=sample_valid && eventful && prefix_at[16];
    wire urgent_push=saturated && urgent_present && !urgent_at[16];
    wire [15:0] prefix_mask=prefix_push ? prefix_at[15:0] : 0;
    wire [15:0] urgent_mask=urgent_push ? urgent_at[15:0] : 0;
    assign input_overflow=sticky_hint || response_data[27];

    always @(posedge clk) begin
        if(rst) begin
            request_sync1<=0;request_sync2<=0;accepted<=0;bank<=0;descriptor<=0;
            prefix_ptr<=1;urgent_ptr<=1;open_ack<=0;open_ack_data<=0;open_lost<=0;
            sticky_hint<=0;prefix_write<=0;urgent_write<=0;prefix_wdata<=0;urgent_wdata<=0;
        end else begin
            request_sync1<=request_token;request_sync2<=request_sync1;
            if(accept) accepted<=request_sync2;
            if(fence) begin
                descriptor<=~descriptor;sealed_bank<=bank;sealed_ack<=open_ack;sealed_ack_data<=open_ack_data;
                sealed_prefix_end<=prefix_ptr;sealed_urgent_end<=urgent_ptr;sealed_lost<=open_lost;
                sealed_levels<=levels;sealed_shift<=key_shift;
                bank<=~bank;open_ack<=ack_rise;open_ack_data<=ack_data;
            end
            prefix_ptr<=prefix_push ? prefix_at<<1 : prefix_at;
            urgent_ptr<=urgent_push ? urgent_at<<1 : urgent_at;
            open_lost<=saturated || (!fence && open_lost);
            if(saturated) sticky_hint<=1;
            prefix_write<=current_bank ? {prefix_mask,16'd0} : {16'd0,prefix_mask};
            urgent_write<=current_bank ? {urgent_mask,16'd0} : {16'd0,urgent_mask};
            prefix_wdata<={levels,edges,key_valid,key_index,key_shift};
            urgent_wdata<={levels,winning_urgent};
        end
    end

    localparam WAIT=0,START=1,PREFIX=2,URGENT=3,LOSS=4,OBS=5,ISSUE=6,RESULT=7;
    reg [2:0] stage,resume;
    reg handled;
    reg [16:0] word;
    reg [1:0] command;
    reg [9:0] command_levels,command_edges;
    reg command_key_valid,command_shift;
    reg [7:0] command_key;
    wire [27:0] pre=sealed_bank ? prefix_rdata[55:28] : prefix_rdata[27:0];
    wire [11:0] urg=sealed_bank ? urgent_rdata[23:12] : urgent_rdata[11:0];
    wire [15:0] read_prefix=(stage==PREFIX && word!=sealed_prefix_end) ? word[15:0] : 0;
    wire [15:0] read_urgent=(stage==URGENT && word!=sealed_urgent_end) ? word[15:0] : 0;
    assign prefix_read=sealed_bank ? {read_prefix,16'd0} : {16'd0,read_prefix};
    assign urgent_read=sealed_bank ? {read_urgent,16'd0} : {16'd0,read_urgent};
    wire worker_ready,worker_valid,mem_valid,mem_write;
    wire [3:0] mem_addr;
    wire [25:0] mem_wdata;
    wire [36:0] snapshot;
    wire [15:0] addressed=16'd1<<mem_addr;
    assign slot_read=(mem_valid && !mem_write) ? addressed : 0;

    shama_input_slot_worker worker(.clk,.rst,.step(worker_step),.cmd_valid(stage==ISSUE),
        .resp_ready(stage==RESULT),.cmd(command),.cmd_ack_data(sealed_ack_data),
        .cmd_levels(command_levels),.cmd_edges(command_edges),.cmd_key_valid(command_key_valid),
        .cmd_shift(command_shift),.cmd_key(command_key),.cmd_ready(worker_ready),.resp_valid(worker_valid),
        .snapshot,.mem_valid,.mem_write,.mem_addr,.mem_wdata,.mem_ready(1'b1),.mem_rdata(slot_rdata));

    always @(posedge clk) begin
        if(rst) begin
            stage<=WAIT;handled<=0;word<=1;response_token<=0;response_data<=0;
            slot_write<=0;slot_wdata<=0;
        end else begin
            // Keep address/data registered through the following real low-phase write.
            slot_write<=(worker_step && mem_valid && mem_write) ? addressed : 0;
            if(worker_step && mem_valid && mem_write) slot_wdata<=mem_wdata;
            if(worker_step) case(stage)
                WAIT:if(descriptor!=handled) begin handled<=descriptor;word<=1;stage<=START;end
                START:if(sealed_ack) begin command<=1;resume<=PREFIX;stage<=ISSUE;end else stage<=PREFIX;
                PREFIX:if(word==sealed_prefix_end) begin word<=1;stage<=URGENT;end
                    else begin command<=2;command_levels<=pre[27:18];command_edges<=pre[17:8];
                        command_key_valid<=pre[7];command_key<=keymap(pre[6:4],pre[3:1],pre[0]);
                        word<=word<<1;resume<=PREFIX;stage<=ISSUE;end
                URGENT:if(word==sealed_urgent_end) stage<=LOSS;
                    else begin command<=2;command_levels<=urg[11:2];command_edges<=10'b0001000000<<urg[1:0];
                        command_key_valid<=0;word<=word<<1;resume<=URGENT;stage<=ISSUE;end
                LOSS:if(sealed_lost) begin command<=3;resume<=OBS;stage<=ISSUE;end else stage<=OBS;
                OBS:begin command<=0;command_levels<=sealed_levels;command_shift<=sealed_shift;
                    resume<=WAIT;stage<=ISSUE;end
                ISSUE:if(worker_ready) stage<=RESULT;
                RESULT:if(worker_valid) begin
                    if(resume==WAIT) begin response_data<=snapshot;response_token<=accepted;end
                    stage<=resume;
                end
                default:stage<=WAIT;
            endcase
        end
    end
endmodule
