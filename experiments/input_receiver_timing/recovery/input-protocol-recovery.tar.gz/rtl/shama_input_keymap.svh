    function automatic [7:0] keymap(input integer r,input integer c,input logic shifted);
        begin
            case(r)
                0: keymap = "A"+c;
                1: keymap = "I"+c;
                2: keymap = "Q"+c;
                3: case(c)
                    0:keymap="Y";1:keymap="Z";2:keymap="0";3:keymap="1";
                    4:keymap="2";5:keymap="3";6:keymap="4";default:keymap="5";
                endcase
                4: case(c)
                    0:keymap="6";1:keymap="7";2:keymap="8";3:keymap="9";
                    4:keymap=8'h20;5:keymap=8'h0d;6:keymap=8'h08;default:keymap=8'h09;
                endcase
                5: case(c)
                    0:keymap=".";1:keymap=",";2:keymap="-";3:keymap="_";
                    4:keymap="/";5:keymap="+";6:keymap="=";default:keymap=":";
                endcase
                6: case(c)
                    0:keymap="[";1:keymap="]";2:keymap="(";3:keymap=")";
                    4:keymap="!";5:keymap="?";6:keymap="*";default:keymap=";";
                endcase
                default: case(c)
                    0:keymap=8'h80; // up
                    1:keymap=8'h81; // down
                    2:keymap=8'h82; // left
                    3:keymap=8'h83; // right
                    4:keymap=8'h1b; // escape
                    5:keymap=8'h7f; // delete
                    6:keymap=" ";
                    default:keymap=8'h00; // Shift toggle is consumed locally.
                endcase
            endcase
            if(shifted) begin
                if(keymap>="A" && keymap<="Z") keymap=keymap+8'd32;
                // The alternate punctuation bank supplies every remaining
                // printable ASCII character without multi-key matrix chords.
                if(r==5) case(c)
                    0:keymap=8'h22;1:keymap=8'h27;2:keymap="<";3:keymap=">";
                    4:keymap=8'h5c;5:keymap="|";6:keymap="@";default:keymap=8'h60;
                endcase
                if(r==6) case(c)
                    0:keymap="{";1:keymap="}";2:keymap="#";3:keymap="$";
                    4:keymap="%";5:keymap="&";6:keymap="^";default:keymap="~";
                endcase
            end
        end
    endfunction
