from pathlib import Path
import subprocess,json,os,sys
from itertools import groupby
f=Path('/tmp/shama-step-control');p=json.loads((f/'pins.json').read_bytes());events={}
def at(t,**changes):events.setdefault(t,{}).update(changes)
def pulses(t,n):
 for i in range(n):
  at(t+70*i,clk=True);at(t+70*i+35,clk=False)
 return t+70*n
at(0,rst=True,power_switch=True,pause_switch=True)
t=pulses(2000,16)
at(t+100,rst=False)
t=pulses(t+1800,40)
p1=t+27;at(p1,step_button=True);at(p1+119,step_button=False)
t=pulses(t,48)
# Stop low with no boundary consume. Restart must preserve the one queued step.
t=pulses(t+1300,38)
# Present the real 18-bit default-divider predecessor for two distinct profiles:
# first leave it stable long enough to diagnose locally qualified clear, then
# exercise the production one-source-epoch-wide predicate in a later test.
setpre=t+160;at(setpre,**{f'word{i}':True for i in range(17)})
t=pulses(setpre+1800,38)
at(t+100,word17=True,**{f'word{i}':False for i in range(17)})
t=pulses(t+1400,24)
t=pulses(t+1000,16)
end=t+1200
pos=sorted(events);steps=[]
for j,a in enumerate(pos):
 stop=pos[j+1] if j+1<len(pos) else end
 steps.append({'ticks':stop-a,'drive':events[a]})
case={**p,'initial_ticks':0,'capture_trace':True,'steps':steps}
src=f/'set-retain.json';src.write_text(json.dumps(case));result=f/'set-retain-result.json'
with result.open('wb') as out:subprocess.run([os.environ['SHAMA_MCHPRS_TERRAIN_RUNNER'],str(f/'world.jsonl'),str(src),'1500'],check=True,stdout=out)
r=json.loads(result.read_bytes());w=r['traces']
def tr(k):return [i for i in range(1,len(w[k])) if w[k][i]!=w[k][i-1]]
def rises(k):return [i for i in tr(k) if w[k][i]]
def active(k):return [(a,b) for a,b in zip([0,*tr(k)],[*tr(k),end]) if w[k][a]]
from bisect import bisect_left,bisect_right
stats={}
for n in ('step_previous','step_pending','core_gate'):
 ce=rises(n+'_C');ds=tr(n+'_D')
 margins=[(e,e-(ds[bisect_right(ds,e)-1] if bisect_right(ds,e) else 0),(ds[bisect_left(ds,e)] if bisect_left(ds,e)<len(ds) else end)-e) for e in ce if e>2000]
 stats[n]={'clock_high_widths':sorted({b-a for a,b in active(n+'_C') if a and b!=end}),'D_high':active(n+'_D'),'Q_high':active(n+'_Q'),
           'worst_setup':min(x for _,x,_ in margins),'worst_hold':min(x for _,_,x in margins),'violations':[row for row in margins if row[1]<8 or row[2]<2]}
rpt={'native':r['status'],'world':r['imported_stream_sha256'],'case':r['scenario_sha256'],'pending_native':r['pending_ticks_after_scenario'],
 'reset_release':next(t for t,d in events.items() if d.get('rst') is False),'step_rise':p1,'step_fall':p1+119,'first_possible_consume':setpre,
 'registers':stats,'grant_high':active('grant'),'expected_one_sustained_pending_before_consume':True,
 'expected_pending_hold_violations':[(a,b) for a,b in active('step_pending_Q') if p1<a<b<setpre],
 'whole_machine_verified':False}
(f/'set-retain-review.json').write_text(json.dumps(rpt,indent=2));print(json.dumps(rpt,indent=2),flush=True)
