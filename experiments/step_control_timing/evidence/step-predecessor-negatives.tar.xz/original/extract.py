import json,hashlib
from collections import Counter
from pathlib import Path
from shamaos.hardware.logic import template_for
from shamaos.hardware.partition_planner import load_mapped_module,Graph,build_plan
from shamaos.hardware.bounded_facade import place_with_egress
from shamaos.bounded_system import BoundedPartition
from shamaos.worldio import NativeWorldWriter
from shamaos.mchprs_import import export_world
folder=Path('/tmp/shama-step-control');mapped=folder/'shell.json'
m,meta=load_mapped_module(mapped,'shama_soc'); port=m['ports'];cells=m['cells'];g={}
boundary={n:v['bits'] for n,v in port.items() if n in ['clk','power_switch','pause_switch','step_button']}
boundary['rst']=cells['u_startup']['connections']['rst'];boundary['word']=cells['u_raw_counter']['connections']['value'][:18]
watch={k:m['netnames'][k]['bits'][0] for k in ['core_gate','step_previous','step_pending']}
out={'core_gate':cells['u_startup']['connections']['core_gate']}
assert out['core_gate']==[watch['core_gate']]
term={b:n for n,a in boundary.items() for b in a}
allq={};used=set();dr={}
for n,c in cells.items():
 if n.startswith('u_'):continue
 for key in ['Q','Y']:
  if key in c['connections']:dr[c['connections'][key][0]]=n
stack=list(watch.values())
while stack:
 x=stack.pop()
 if x in term:used.add(x);continue
 if x in ('0','1'):continue
 n=dr[x]
 if n in g:continue
 c=cells[n];g[n]=c
 if 'Q' in c['connections']:allq[x]=n
 for k,a in c['connections'].items():
  if k not in ('Q','Y'):stack.extend(a)
assert used==set(term) and set(allq)==set(watch.values())
ports={k:{'direction':'input','bits':a} for k,a in boundary.items()};ports.update({k:{'direction':'output','bits':a} for k,a in out.items()})
cut={'modules':{'shama_step_control':{'ports':ports,'cells':g,'netnames':{k:{'bits':[v]} for k,v in watch.items()}}}}
p=folder/'original.json';p.write_text(json.dumps(cut))
# All genuine feedback paths, stopping at real storage. The clock polarity is
# traced separately, including the mapped inversion ahead of core_gate.C.
names={v:k for k,v in watch.items()}
def paths(bit0,seen=()):
 if bit0 in names:return [(names[bit0],seen)]
 if bit0 in term:return [(term[bit0],seen)]
 if bit0 in ('0','1'):return [(bit0,seen)]
 n=dr[bit0];c=g[n]
 return [path for k,v in c['connections'].items() if k not in ('Q','Y') for path in paths(v[0],(n,)+seen)]
legs={}
for name,bit0 in watch.items():
 c=g[allq[bit0]]
 legs[name]={p:[(k,len(v),v) for k,v in paths(c['connections'][p][0])] for p in ('C','D')}
grade={'shell_hash':meta['container_sha256'],'cells':dict(Counter(c['type'] for c in g.values())),'input_bits':len(term),'source':boundary,'registers':watch,'causal_legs':legs}
(folder/'paths.json').write_text(json.dumps(grade,indent=2))
print(grade['cells'],[(r,[(end,[(k,n) for k,n,v in a if k in watch or end=='C']) for end,a in role.items()]) for r,role in legs.items()],flush=True)
if __name__=='__main__':
 graph=Graph.read(p,'shama_step_control');plan=build_plan(graph,cell_budget=64,boundary_budget=128,domain_budget=128,arity=4)
 placed=place_with_egress(graph,plan,surface_y=-61,maximum_y=285)
 part=BoundedPartition.from_placed(p,'shama_step_control',plan,placed,surface_y=-61,maximum_y=285)
 coords=lambda v:[v.x,v.y,v.z]
 ins={k:coords(v[0]) for k,v in part.input_ports.items() if k!='word'}
 ins.update({f'word{i}':coords(v) for i,v in enumerate(part.input_ports['word'])})
 outputs={**ins,'grant':coords(part.output_ports['core_gate'][0])}
 for role,q in watch.items():
  name=allq[q];origin=part.cell_origins[name];tpl=template_for(part.cell_types[name])
  for k,pin in tpl.pins.items():outputs[role+'_'+k]=coords(origin.offset(pin.x,pin.y,pin.z))
 (folder/'pins.json').write_text(json.dumps({'inputs':ins,'outputs':outputs},indent=2))
 with NativeWorldWriter(folder/'world',surface_y=-61,spawn_platform=False) as writer:
  writer.set_blocks(part.iter_placements());receipt=writer.validate();assert receipt['status']=='passed'
 (folder/'geometry.json').write_text(json.dumps(receipt,indent=2));export_world(folder/'world',folder/'world.jsonl');print('ready',flush=True)
