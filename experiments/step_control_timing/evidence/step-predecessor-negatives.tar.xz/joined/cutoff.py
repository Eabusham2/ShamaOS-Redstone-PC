from pathlib import Path
import sys,os,json,subprocess,gzip,shutil
f=Path('/tmp/shama-step-joined');p=json.loads((f/'pins.json').read_bytes());events={}
def at(t,**changes):events.setdefault(t,{}).update(changes)
def raw(a,b):
 for ts in range(a,b,70):at(ts,clk=True);at(ts+35,clk=False)
def word(t,v):at(t,**{f'word{i}':bool(v&(1<<i)) for i in range(18)})
at(0,power_switch=True,pause_switch=True)
raw(2030,17430)
at(14017,step_button=True);at(14136,step_button=False)
raw(19530,23520)
def episode(t,width):
 for i in range(32):word(t+i*70,0x1ffe0+i)
 start=t+32*70
 for i in range(width//70):word(start+i*70,0x20000+i)
 word(start+width,0)
 return start
for i in range(26):word(21000+46+70*i,0x1ffe0+i)
# Stop permanently at 0x1fff9. No actual predecessor or divided rise is applied.
p1=p2=0
end=27500
ks=sorted(events);steps=[{'ticks':b-a,'drive':events[a]} for a,b in zip(ks,[*ks[1:],end])]
watch=['clk','word17','step_button','rst','startup_rst','startup_core_clk','startup_divider_high','startup_core_gate','startup_clock_hold','startup_divided_clock_active_Q','step_pending_C','step_pending_D','step_pending_Q','step_previous_C','step_previous_D','step_previous_Q','core_gate_C','core_gate_D','core_gate_Q','grant','set_path_Q','clear_path_Y','set_path_Y','event_join_Y']
p['outputs']={k:p['outputs'][k] for k in watch};case={**p,'initial_ticks':0,'capture_trace':True,'steps':steps}
src=f/'stop-before-predecessor.json';src.write_text(json.dumps(case))
with gzip.open(f/'stop-before-predecessor-result.json.gz','wb',compresslevel=1) as out,subprocess.Popen([os.environ['SHAMA_MCHPRS_TERRAIN_RUNNER'],str(f/'world.jsonl'),str(src),'2500'],stdout=subprocess.PIPE) as proc:
 shutil.copyfileobj(proc.stdout,out,65536)
 if proc.wait():raise SystemExit(proc.returncode)
with gzip.open(f/'stop-before-predecessor-result.json.gz','rb') as ff:r=json.load(ff)
w=r['traces'];assert r['ticks']==end and r['pending_ticks_after_scenario']==0
report={'world':r['imported_stream_sha256'],'case':r['scenario_sha256'],'pending_native':0,'source_high_ranges':[[p1,p1+2100],[p2,p2+2800]],'edges':{}}
for k in watch:
 v=w[k];ch=[i for i in range(1,len(v)) if v[i]!=v[i-1]]
 if len(ch)<200:report['edges'][k]=[[t,int(v[t])] for t in ch]
print(json.dumps(report,indent=2))
(f/'stop-before-predecessor-review.json').write_text(json.dumps(report,indent=2))
