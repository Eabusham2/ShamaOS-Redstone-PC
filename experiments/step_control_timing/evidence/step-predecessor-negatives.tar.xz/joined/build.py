from pathlib import Path
import json,sys
from shamaos.model import Vec3,Placement
from shamaos.bounded_system import BoundedPartition,place_startup_control
from shamaos.hardware.bounded_facade import place_with_egress
from shamaos.hardware.partition_planner import Graph,build_plan
from shamaos.hardware.pulse import rotate_block
from shamaos.hardware.memory import SUPPORT,repeater
from shamaos.hardware.routing import _wire_for_point
from shamaos.worldio import NativeWorldWriter
from shamaos.mchprs_import import export_world
f=Path('/tmp/shama-step-joined');reason=Path('/tmp/shama-step-reason');startup=Path('/tmp/named-r2-positive')
g=Graph.read(reason/'mapped.json','shama_step_control')
plan=build_plan(g,cell_budget=64,boundary_budget=128,domain_budget=128,arity=4)
p=place_with_egress(g,plan,surface_y=-61,maximum_y=285)
ctrl=BoundedPartition.from_placed(reason/'mapped.json','shama_step_control',plan,p,surface_y=-61,maximum_y=285)
start=place_startup_control(startup/'startup.json',surface_y=-61,maximum_y=285)
old=json.loads((startup/'power-cycle.json').read_bytes());pins=json.loads((reason/'pins.json').read_bytes())
def turn(v):return Vec3(600-v.x,v.y,694-v.z)
def arr(v):return [v.x,v.y,v.z]
sp={k:turn(Vec3(*v)) for k,v in (old['inputs']|old['outputs']).items()}
rp={k:Vec3(*v) for k,v in (pins['inputs']|pins['outputs']).items()}
def approach(a,level,step,target):
 pts=[a];loc=a
 while loc.z!=target:
  i=len(pts)
  dz=step;dy=int(loc.y<level and i>4 and i%8 in (1,2,3,4))
  loc=loc.offset(dy=dy,dz=dz);pts.append(loc)
 assert loc.y==level
 return pts
def link(pts):
 legal={i for i in range(1,len(pts)-1) if pts[i-1].y==pts[i].y==pts[i+1].y and
    (pts[i-1].x==pts[i].x==pts[i+1].x or pts[i-1].z==pts[i].z==pts[i+1].z)}
 reps=[1];assert 1 in legal
 while len(pts)-1-reps[-1]>12:
  reps.append(max(x for x in range(reps[-1]+1,reps[-1]+13) if x in legal))
 if len(pts)-2 not in reps:reps.append(len(pts)-2)
 reps=set(reps)
 for i,v in enumerate(pts[1:-1],1):
  if i in reps:
   q=pts[i+1];d='east' if q.x>v.x else 'west' if q.x<v.x else 'south' if q.z>v.z else 'north';state=repeater(d)
  else:state=_wire_for_point(pts,i)
  yield Placement(v.offset(dy=-1),SUPPORT,'shared-route')
  yield Placement(v,state,'shared-route')
routes=[]
for n,(src,dst) in enumerate((('clk','clk'),('power_switch','power_switch'),('word17','divider_high'),('grant','core_gate'),('rst','rst'))):
 a=rp[src].offset(dz=1) if src in ('clk','power_switch','word17') else rp[src]
 b=sp[dst];level=-59+n*4
 l=approach(a,level,1,394);r=approach(b,level,-1,394);assert l[-1].x<r[-1].x
 pts=l+[Vec3(x,level,394) for x in range(l[-1].x+1,r[-1].x)]+r[::-1]
 routes.append(list(link(pts[::-1] if src=='rst' else pts)))
with NativeWorldWriter(f/'world',surface_y=-61,spawn_platform=False) as wr:
 wr.set_blocks(ctrl.iter_placements())
 wr.set_blocks(Placement(turn(b.pos),rotate_block(b.block,2),b.component) for b in start.iter_placements())
 for path in routes:wr.set_blocks(path)
 report=wr.validate();assert report['status']=='passed'
(f/'geometry.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
export_world(f/'world',f/'world.jsonl')
ins={k:v for k,v in pins['inputs'].items() if k!='rst'}
ins['reset_button']=arr(sp['reset_button'].offset(dz=-2))
out=pins['outputs']|{'startup_'+k:arr(v) for k,v in sp.items()}
(f/'pins.json').write_text(json.dumps({'inputs':ins,'outputs':out},indent=2))
