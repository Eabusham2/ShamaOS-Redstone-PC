`include "shama_native_cells.svh"
module shama_step_control(input wire clk,power_switch,pause_switch,step_button,rst,
    input wire [17:0] word, output reg core_gate);
    reg step_previous,step_pending;
    wire press,set_event,clear_event,set_clock,clear_clock,set_inhibited,pending_clock,grant_clock;
    WRITE_GUARD detect_press(.A(step_button),.B(step_previous),.Y(press));
    WRITE_GUARD ignore_reset(.A(press),.B(rst),.Y(set_event));
    always @(posedge clk) step_previous<=step_button && !rst;
    wire commit=(&word[16:0]) && !word[17] && core_gate;
    assign clear_event=rst || (!press && commit);
    CLOCK_GUARD_ACK set_path(.A(clk),.B(!set_event),.Y(set_clock),.Q(set_inhibited));
    CLOCK_GUARD clear_path(.A(clk),.B(!clear_event),.Y(clear_clock));
    CLOCK_OR event_join(.A(set_clock),.B(clear_clock),.Y(pending_clock));
    always @(posedge pending_clock) step_pending<=!set_inhibited;
    CLOCK_GUARD write_grant(.A(!clk),.B(!rst && word[17]),.Y(grant_clock));
    always @(posedge grant_clock) core_gate<=rst || !pause_switch || step_pending || !power_switch;
endmodule
