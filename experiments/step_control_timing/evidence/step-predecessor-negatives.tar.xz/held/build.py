import json,sys
from pathlib import Path
from collections import Counter
from shamaos.hardware.logic import template_for
from shamaos.hardware.partition_planner import load_mapped_module,Graph,build_plan
from shamaos.hardware.bounded_facade import place_with_egress
from shamaos.bounded_system import BoundedPartition
from shamaos.worldio import NativeWorldWriter
from shamaos.mchprs_import import export_world
from shamaos.synthesis import synthesize_json
folder=Path(sys.argv[1]);p=folder/'mapped.json';repo=Path('/tmp/shama-measured-raw-counter')
synthesize_json([folder/'qualified.sv'],repo_root=repo,top='shama_step_control',output_json=p)
m,meta=load_mapped_module(p,'shama_step_control');cells=m['cells'];watch={k:m['netnames'][k]['bits'][0] for k in ('step_previous','step_pending','core_gate')}
allq={c['connections']['Q'][0]:n for n,c in cells.items() if c['type']=='DFF'}
assert set(allq)==set(watch.values())
if __name__=='__main__':
 graph=Graph.read(p,'shama_step_control');plan=build_plan(graph,cell_budget=64,boundary_budget=128,domain_budget=128,arity=4)
 placed=place_with_egress(graph,plan,surface_y=-61,maximum_y=285)
 part=BoundedPartition.from_placed(p,'shama_step_control',plan,placed,surface_y=-61,maximum_y=285)
 coords=lambda v:[v.x,v.y,v.z]
 ins={k:coords(v[0]) for k,v in part.input_ports.items() if k!='word'}
 ins.update({f'word{i}':coords(v) for i,v in enumerate(part.input_ports['word'])})
 outputs={**ins,'grant':coords(part.output_ports['core_gate'][0])}
 for role,q in watch.items():
  name=allq[q];origin=part.cell_origins[name];tpl=template_for(part.cell_types[name])
  for k,pin in tpl.pins.items():outputs[role+'_'+k]=coords(origin.offset(pin.x,pin.y,pin.z))
 for name in ('set_path','clear_path','event_join','write_grant','detect_press','ignore_reset'):
  origin=part.cell_origins[name];tpl=template_for(part.cell_types[name])
  for k,pin in tpl.pins.items():outputs[name+'_'+k]=coords(origin.offset(pin.x,pin.y,pin.z))
 (folder/'pins.json').write_text(json.dumps({'inputs':ins,'outputs':outputs},indent=2))
 with NativeWorldWriter(folder/'world',surface_y=-61,spawn_platform=False) as writer:
  writer.set_blocks(part.iter_placements());receipt=writer.validate();assert receipt['status']=='passed'
 (folder/'geometry.json').write_text(json.dumps(receipt,indent=2));export_world(folder/'world',folder/'world.jsonl');print('ready',flush=True)
