module original(input wire clk,power_switch,rst,pause_switch,step_button,input wire [17:0] word,output logic core_gate,step_pending,step_previous);
    localparam CORE_DIV_BIT=17;
    wire [17:0] core_div_counter=word;
    always_ff @(posedge clk) begin
        if(rst) begin step_pending<=0;step_previous<=0;end
        else begin
            step_previous<=step_button;
            if(step_button && !step_previous) step_pending<=1;
            else if(core_div_counter==((1<<CORE_DIV_BIT)-1) && core_gate) step_pending<=0;
        end
    end

    // Gate changes only during a low divider phase. A step therefore emits a
    // complete normal-length core pulse; it never shortens the settling time.
    always_ff @(negedge clk) begin
        if(rst) core_gate<=1;
        else if(!core_div_counter[CORE_DIV_BIT])
            core_gate<=!pause_switch || step_pending || !power_switch;
    end

endmodule
