module miter(input wire next_raw, input wire [3:0] next_controls, input wire [17:0] next_word);
    reg clk=0;
    reg [3:0] controls=0;
    reg [17:0] word=0;
    wire rst=controls[0], power_switch=controls[1],pause_switch=controls[2],step_button=controls[3];
    wire [2:0] observed,reference;
    original refmod(.clk,.power_switch,.rst,.pause_switch,.step_button,.word,
                    .core_gate(reference[0]),.step_pending(reference[1]),.step_previous(reference[2]));
    shama_step_control dut(.clk,.power_switch,.rst,.pause_switch,.step_button,.word,
                    .core_gate(observed[0]),.step_pending(observed[1]),.step_previous(observed[2]));
    always @($global_clock) begin
        if (clk!=next_raw) begin assume(controls==next_controls);assume(word==next_word);end
        clk<=next_raw;controls<=next_controls;word<=next_word;
    end
    always @* assert(observed==reference);
endmodule
